#******************************************************************************/
#/* Component Name:  Renesas content certificate checker                      */
#/*****************************************************************************/
#/* Product      : Renesas R-Car Gen 3 devices                                */
#/* Device(s)    : R-Car Gen 3                                                */
#/*****************************************************************************/
#    Copyright (C) 2020  Renesas Electronics America, Inc.
#
# DISCLAIMER
# This software is supplied by Renesas Electronics Corporation and is only
# intended for use with Renesas products. No other uses are authorized. This
# software is owned by Renesas Electronics Corporation and is protected under
# all applicable laws, including copyright laws.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
# THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
# LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
# EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS
# CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
# INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED
# TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGES.
#
# Renesas reserves the right, without notice, to make changes to this software
# and to discontinue the availability of this software. By using this software,
# you agree to the additional terms and conditions found by accessing the
# following link:
# www.renesas.com/disclaimer

#/*****************************************************************************/
#* History:
#*   See CHANGELOG.md
#******************************************************************************/
VERSION = "1.0.5"

import argparse
import sys
import binascii
import struct
import os

# Static defines
DEFAULT_LOWER_RANGE_TYPE_A      = 0xe6300400       # Default range lower bound
DEFAULT_LOWER_RANGE_TYPE_B      = 0xeb200400       # Default range lower bound
DEFAULT_UPPER_RANGE_TYPE_A      = 0xe6357fc0       # Default range upper bound
DEFAULT_UPPER_RANGE_TYPE_B      = 0xe6367fc0       # Default range upper bound
DEFAULT_UPPER_RANGE_TYPE_C      = 0xe6317fc0       # Default range upper bound
DEFAULT_UPPER_RANGE_TYPE_D      = 0xeb2f7fc0       # Default range upper bound
DEFAULT_ALIGNMENT               = 1                # Default is 1 byte alignment

LOWER_RANGE_LOOKUP       = {'D3' : DEFAULT_LOWER_RANGE_TYPE_A,
                            'E3' : DEFAULT_LOWER_RANGE_TYPE_A,
                            'H3' : DEFAULT_LOWER_RANGE_TYPE_A,
                            'M3N': DEFAULT_LOWER_RANGE_TYPE_A,
                            'M3W': DEFAULT_LOWER_RANGE_TYPE_A,
                            'V3M': DEFAULT_LOWER_RANGE_TYPE_A,
                            'V3H': DEFAULT_LOWER_RANGE_TYPE_B}

UPPER_RANGE_LOOKUP       = {'D3' : DEFAULT_UPPER_RANGE_TYPE_C,
                            'E3' : DEFAULT_UPPER_RANGE_TYPE_C,
                            'H3' : DEFAULT_UPPER_RANGE_TYPE_A,
                            'M3N': DEFAULT_UPPER_RANGE_TYPE_A,
                            'M3W': DEFAULT_UPPER_RANGE_TYPE_A,
                            'V3M': DEFAULT_UPPER_RANGE_TYPE_B,
                            'V3H': DEFAULT_UPPER_RANGE_TYPE_D}

OFFSET_2048                     = 0x154            # Byte offset of start IPL_Start_Address with 2048 bit key
OFFSET_3072                     = 0x1D4            # Byte offset of start IPL_Start_Address with 3072 bit key
OFFSET_4096                     = 0x254            # Byte offset of start IPL_Start_Address with 4096 bit key

CERTIFICATE_LENGTH              = {616  : "2048",  # Size in bytes of certificate with 2048 bit key
                                   872  : "3072",  # Size in bytes of certificate with 3072 bit key
                                   1128 : "4096"}  # Size in bytes of certificate iwth 4096 bit key

MSG_FOUND_OK             = "(Passed) Address in range found (expected)"
MSG_FOUND_SIGNATURE      = "(Failed) Address found in signature (Regenerate Certificate)"
MSG_FOUND_PUB            = "(Failed) Address found in public key (Regenerate secure boot key pair)"
MSG_NOT_FOUND_OK         = "(Passed) No illegal value found in check range"
MSG_NOT_FOUND_UNEXPECTED = "(Failed) No value found in check range (Expecting a valid address. Check key size or range)"

# Function to check the certificate contents against a check address range
def check_cert(filename, lower_range, upper_range, silent_mode, align):
    with open(filename, "rb") as file:
        # Read in certificate
        certificate = file.read()
        certificate_length = len(certificate)
        print("Reading in certificate: " + filename)

        # Find certificate key size
        if certificate_length not in CERTIFICATE_LENGTH:
            print("This doesn't seem to be a valid certificate. Certificate length does not match expected value. The checker is intended to verify IPL content certificates and only checks certificates with a single signed image. Please check input file.")
            quit()
        else:
            key_size = CERTIFICATE_LENGTH.get(certificate_length)
            if not silent_mode:
                print("Verifying a certificate with key size: " + key_size)

        if not silent_mode:
            print("Checking for values in range: " +
                  '0x'+ hex(lower_range)[2:].zfill(8) + " - "
                  '0x'+ hex(upper_range)[2:].zfill(8) + " with " + str(align) + " byte offset")

        # Extract certificate information
        value_2048 = struct.unpack_from('<I', certificate, OFFSET_2048)[0]
        value_3072 = struct.unpack_from('<I', certificate, OFFSET_3072)[0]
        value_4096 = struct.unpack_from('<I', certificate, OFFSET_4096)[0]

        # Check for vulnerabily
        if not silent_mode:
            print("")
            print("Checking IPL_Start_Address values:")
        if ('2048' == key_size):
            msg_2048 = MSG_FOUND_OK if check_range(value_2048, lower_range, upper_range, align) else MSG_NOT_FOUND_UNEXPECTED
            msg_3072 = MSG_FOUND_SIGNATURE if check_range(value_3072, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
            msg_4096 = MSG_FOUND_SIGNATURE if check_range(value_4096, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
        elif ('3072' == key_size):
            msg_2048 = MSG_FOUND_PUB if check_range(value_2048, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
            msg_3072 = MSG_FOUND_OK if check_range(value_3072, lower_range, upper_range, align) else MSG_NOT_FOUND_UNEXPECTED
            msg_4096 = MSG_FOUND_SIGNATURE if check_range(value_4096, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
        elif ('4096' == key_size):
            msg_2048 = MSG_FOUND_PUB if check_range(value_2048, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
            msg_3072 = MSG_FOUND_PUB if check_range(value_3072, lower_range, upper_range, align) else MSG_NOT_FOUND_OK
            msg_4096 = MSG_FOUND_OK if check_range(value_4096, lower_range, upper_range, align) else MSG_NOT_FOUND_UNEXPECTED
        else:
            print("Should never enter this case. Something has gone terribly wrong!")
            quit()

        # Print check messages
        print("2048 bit key offset: " + '0x' + hex(value_2048)[2:].zfill(8) + " " + msg_2048)
        print("3072 bit key offset: " + '0x' + hex(value_3072)[2:].zfill(8) + " " + msg_3072)
        print("4096 bit key offset: " + '0x' + hex(value_4096)[2:].zfill(8) + " " + msg_4096)

# Function to check if a value is within a range
def check_range(val, lower_range, upper_range, align):
    if(val >= lower_range):
        if(val <= upper_range):
            if not (val % align):
                return(True)
    return(False)

def main():

    # Define input arguments parser
    parser = argparse.ArgumentParser(description="This script checks for R-Car content certificates that could be affected by the vulnerability described in ABUV_000021. This checker only verifies IPL content certificates with a single signed image. It requires python 3.")
    parser.add_argument('device', choices=['D3','E3','H3','M3N','M3W','V3M','V3H'], help="Please select a device")
    parser.add_argument('filename', help='Please specify the content certificate file to check.')
    parser.add_argument('-l','--lower_range',nargs=1,type=lambda x: int(x,0), help="Override default value for lower address range to check")
    parser.add_argument('-u','--upper_range',nargs=1,type=lambda x: int(x,0), help="Override default value for upper address range to check")
    parser.add_argument('-a','--align',nargs=1, type=int, help="Explicitly set alignment check value. Default is 1 byte.")
    parser.add_argument('-s','--silent',action="store_true",help="Silent mode prints only the check message. Useful for automation")

    # Parse the input arguments
    args = parser.parse_args()

    # If not using silent mode print message
    if not args.silent:
        # Print opening message
        print("")
        print("=====================================================================")
        print(" check_cert.py - version " + VERSION)
        print("---------------------------------------------------------------------")
        print(" This is Renesas content certificate checker for R-Car.              ")
        print(" It checks content certificates for weaknesses described in Renesas  ")
        print(" vulnerability ID: ABUV_000021.                                      ")
        print("")
        print(" Copyright (C) 2020  Renesas Electronics America, Inc.               ")
        print(" This program comes with ABSOLUTELY NO WARRANTY.")
        print("=====================================================================")
        print("")
        # Print device choice
        print("Checking for R-Car device: " + args.device)

    # Configure lower address
    if args.lower_range:
        lower_range = args.lower_range[0]
    elif args.device not in LOWER_RANGE_LOOKUP:
        print("Device not found. Should never enter this case.")
        quit()
    else:
        # Look up lower range based on selected device
        lower_range = LOWER_RANGE_LOOKUP.get(args.device)

    # Configure upper address
    if args.upper_range:
        upper_range = args.upper_range[0]
    elif args.device not in UPPER_RANGE_LOOKUP:
        print("Device not found. Should never enter this case.")
        quit()
    else:
        # Look up upper range based on selected device
        upper_range = UPPER_RANGE_LOOKUP.get(args.device)

    if args.align:
        align = args.align[0]
    else:
        align = DEFAULT_ALIGNMENT;


    # Check input file
    if args.filename:
        check_cert(args.filename,lower_range,upper_range,args.silent,align)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
