import argparse

def reverse_bytes(input_file, output_file):
    # Read the binary data from the input file
    with open(input_file, 'rb') as f:
        data = f.read()
    
    # Reverse the byte order
    reversed_data = data[::-1]
    
    # Write the reversed data to the output file
    with open(output_file, 'wb') as f:
        f.write(reversed_data)

def main():
    # Set up argument parsing
    parser = argparse.ArgumentParser(description='Reverse the byte order of a binary file.')
    parser.add_argument('input_file', help='The input binary file.')
    parser.add_argument('output_file', help='The output binary file with reversed byte order.')

    # Parse the arguments
    args = parser.parse_args()

    # Reverse the bytes in the input file and write to the output file
    reverse_bytes(args.input_file, args.output_file)

    print(f'Reversed byte order written to {args.output_file}')

if __name__ == '__main__':
    main()