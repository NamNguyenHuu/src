#!/bin/bash

# Copyright(c) 2024 Renesas Electronics Corporation.
# All rights reserved.
# RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

# This program is licensed under the license agreement between Renesas
# Electronics Corporation and licensee (the "License Agreement") and
# shall be treated as specified in the License Agreement.
# These instructions, statements, and programs are the confidential
# information of Renesas Electronics Corporation. They must be used and
# modified solely for the purpose for which it was furnished by
# Renesas Electronics Corporation.
# All or part of these instructions, statements and programs must not be
# reproduced nor disclosed to any third party in any form, unless permitted
# by the License Agreement.

# THIS SOFTWARE IS PROVIDED BY RENESAS ELEOCTRONICS CORPORATION
# "AS IS“ AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE, SATISFACTORY QUALITY, ACCURACY, TITLE AND
# NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT SHALL RENESAS ELECTRONICS
# CORPORATION BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# PUNITIVE, EXEMPLARY, OR CONSEQUENTIAL DAMAGES HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
# In the event that applicable law does not permit the exclusion or
# limitations of damages in this paragraph, then Renesas disclaims all lability
# under this terms to the maximum extent permitted by law.

# Perform replacement of modulus in Dummy_key.der.

# Constant
readonly SW_VERSION="1.1"
readonly SUPPORTED_OPENSSL_VERSION="1.1.1f"
readonly SUPPORTED_RSA_KEY_LENGTH=(2048 3072 4096)
readonly FORMAT_CHECK_DATA1_PUBKEY_PEM="-----BEGIN PUBLIC KEY-----"
readonly FORMAT_CHECK_DATA2_PUBKEY_PEM="-----END PUBLIC KEY-----"
readonly FORMAT_CHECK_DATA1_DMYKEY_DER="3082"
readonly TMPFILE_MOD_TXT="modulus.txt"
readonly TMPFILE_MOD_BIN="modulus.bin"
readonly TMPFILE_TOP_BIN="top.bin"
readonly TMPFILE_BOT_BIN="bottom.bin"
readonly TMPFILE_SIZE_TOP_BIN=11
readonly ERRCODE_INVALID_ARGMENT=10
readonly ERRCODE_OPENSSL_VERSION_NOT_SUPPORT=11
readonly ERRCODE_PUBKEY_PEM_NOT_EXIST=12
readonly ERRCODE_INDMY_DER_NOT_EXIST=13
readonly ERRCODE_PUBKEY_PEM_BAD_FORMAT=14
readonly ERRCODE_INDMY_DER_BAD_FORMAT=15
readonly ERRCODE_PUBKEY_PEM_KEYLEN_NOT_SUPPORT=16
readonly ERRCODE_INDMY_DER_KEYLEN_NOT_SUPPORT=17
readonly ERRCODE_PEM_AND_DER_KEYLEN_DIFFERENT=18

#######################################
# Display usage.
# Globals:
#   SHELL_NAME
# Arguments:
#   None
# Outputs:
#   Writes error message to stderr
#######################################
usage() {
  echo "$SHELL_NAME version $SW_VERSION" >&2
  echo "The supported openssl version $SUPPORTED_OPENSSL_VERSION" >&2
  echo "Usage: $SHELL_NAME Proper_pubkey.pem input_Dummy_key.der output_Dummy_key.der" >&2
}

#######################################
# After displaying the error message, This shell script exits.
# Globals:
#   None
# Arguments:
#   Error message
#   Status code (1-255)
# Outputs:
#   Writes error message to stderr
#######################################
disp_errmsg_exit() {
  local error_message=$1
  local exit_status=$2

  echo "Error: $error_message." >&2
  usage

  exit "$exit_status"
}

#######################################
# Check the openssl version.
# Globals:
#   SUPPORTED_OPENSSL_VERSION
# Arguments:
#   None
# Outputs:
#   Writes error message to stderr
# Returns:
#   0 Success
#######################################
check_openssl_version() {
  openssl_version=$(openssl version  | awk '{print $2}')

  # If the openssl version is not supported, this shell script exits
  if [ "$openssl_version" != "$SUPPORTED_OPENSSL_VERSION" ]; then
    disp_errmsg_exit "openssl version is not supported by $SHELL_NAME" \
                     $ERRCODE_OPENSSL_VERSION_NOT_SUPPORT
  fi

  return 0
}

#######################################
# Check the arguments of this shell script.
# Globals:
#   ERRCODE_PUBKEY_PEM_NOT_EXIST
#   ERRCODE_INDMY_DER_NOT_EXIST
# Arguments:
#   File name of Proper_pubkey.pem.
#   File name of input_Dummy_key.der.
#   File name of output_Dummy_key.der.
# Outputs:
#   Writes error message to stderr
# Returns:
#   0 Success
#######################################
check_arguments() {
  local pub_pem_file=$1
  local in_der_file=$2
  local out_der_file=$3

  # If the argument file does not exist, this shell script exits
  if [ ! -e "$pub_pem_file" ]; then
    disp_errmsg_exit "Proper_pubkey.pem does not exist" \
                     $ERRCODE_PUBKEY_PEM_NOT_EXIST
  fi

  if [ ! -e "$in_der_file" ]; then
    disp_errmsg_exit "input_Dummy_key.der does not exist" \
                     $ERRCODE_INDMY_DER_NOT_EXIST
  fi

  return 0
}

#######################################
# Check the format of pem and der files.
# Globals:
#   FORMAT_CHECK_DATA1_PUBKEY_PEM
#   FORMAT_CHECK_DATA2_PUBKEY_PEM
#   FORMAT_CHECK_DATA1_DMYKEY_DER
#   ERRCODE_PUBKEY_PEM_BAD_FORMAT
#   ERRCODE_INDMY_DER_BAD_FORMAT
# Arguments:
#   File name of Proper_pubkey.pem.
#   File name of input_Dummy_key.der.
# Outputs:
#   Writes error message to stderr
# Returns:
#   0 Success
#######################################
check_format() {
  local pub_pem_file=$1
  local in_der_file=$2
  local pub_pem_extracted_data
  local in_der_extracted_data

  # Extract the first line of the Proper_pubkey.pem and check it
  set -e
  pub_pem_extracted_data=$(head -n 1 "$pub_pem_file" | tr -d '\r\n')
  set +e
  if [ "$pub_pem_extracted_data" != "$FORMAT_CHECK_DATA1_PUBKEY_PEM" ]; then
    disp_errmsg_exit "Proper_pubkey.pem is invalid format" \
                     $ERRCODE_PUBKEY_PEM_BAD_FORMAT
  fi

  # Extract the last line of the Proper_pubkey.pem and check it
  pub_pem_extracted_data=$(tail -n 1 "$pub_pem_file" | tr -d '\r\n')
  if [ "$pub_pem_extracted_data" != "$FORMAT_CHECK_DATA2_PUBKEY_PEM" ]; then
    disp_errmsg_exit "Proper_pubkey.pem is invalid format" \
                     $ERRCODE_PUBKEY_PEM_BAD_FORMAT
  fi

  # Extract the first byte of input_Dummy_key.der and check it
  set -e
  in_der_extracted_data=$(od -t x1 -N 2 "$in_der_file" | awk 'NR==1{print $2 $3}')
  set +e
  if [ "$in_der_extracted_data" != "$FORMAT_CHECK_DATA1_DMYKEY_DER" ]; then
    disp_errmsg_exit "input_Dummy_key.der is invalid format" \
                     $ERRCODE_INDMY_DER_BAD_FORMAT
  fi

  return 0
}

#######################################
# Get the key length from pem and der files.
# Globals:
#   SUPPORTED_RSA_KEY_LENGTH
#   ERRCODE_PUBKEY_PEM_BAD_FORMAT
#   ERRCODE_INDMY_DER_BAD_FORMAT
#   ERRCODE_PUBKEY_PEM_KEYLEN_NOT_SUPPORT
#   ERRCODE_INDMY_DER_KEYLEN_NOT_SUPPORT
#   ERRCODE_PEM_AND_DER_KEYLEN_DIFFERENT
# Arguments:
#   File name of Proper_pubkey.pem.
#   File name of input_Dummy_key.der.
# Outputs:
#   Writes error message to stderr
# Returns:
#   Index of key length array
#######################################
get_key_length() {
  local pub_pem_file=$1
  local in_der_file=$2
  local key_index=0
  local pub_pem_key_length
  local in_der_key_length
  local key_length
  local pem_match=0
  local der_match=0
  local der_index=0
  local get_key_status
  local supported_key_num=${#SUPPORTED_RSA_KEY_LENGTH[@]}

  # Get the key length of Proper_pubkey.pem.
  pub_pem_key_length=$(openssl rsa -text -pubin -in "$pub_pem_file" -noout | \
                      grep "Public-Key" | \
                      sed -e 's/\(.*\)\([0-9]\{4\}\)\(.*\)/\2/g')
  get_key_status=$?
  if [ "$get_key_status" != "0" ]; then
    disp_errmsg_exit "Proper_pubkey.pem is invalid format" \
                     $ERRCODE_PUBKEY_PEM_BAD_FORMAT
  fi

  # Get the key length of input_Dummy_key.der
  in_der_key_length=$(openssl rsa -in "$in_der_file" -inform der -text -noout | \
                     grep "Private-Key" | \
                     sed -e 's/\(.*\)\([0-9]\{4\}\)\(.*\)/\2/g')
  get_key_status=$?
  if [ "$get_key_status" != "0" ]; then
    disp_errmsg_exit "input_Dummy_key.der is invalid format" \
                     $ERRCODE_INDMY_DER_BAD_FORMAT
  fi
  set +o pipefail

  # Search for supported key lengths
  for key_length in "${SUPPORTED_RSA_KEY_LENGTH[@]}"; do
    if [ "$pub_pem_key_length" -eq "$key_length" ]; then
      pem_match=1
    elif [ $pem_match -eq 0 ]; then
      ((key_index++))
    fi

    if [ "$in_der_key_length" -eq "$key_length" ]; then
      der_match=1
    elif [ $der_match -eq 0 ]; then
      ((der_index++))
    fi
  done

  # If the key length is not supported, this shell script exits
  if [ "$key_index" -ge "$supported_key_num" ]; then
    disp_errmsg_exit "$SHELL_NAME does not support the key length in Proper_pubkey.pem" \
                     $ERRCODE_PUBKEY_PEM_KEYLEN_NOT_SUPPORT
  fi

  if [ "$der_index" -ge "$supported_key_num" ]; then
    disp_errmsg_exit "$SHELL_NAME does not support the key length in input_Dummy_key.der" \
                     $ERRCODE_INDMY_DER_KEYLEN_NOT_SUPPORT
  fi

  if [ "$key_index" -ne "$der_index" ]; then
    disp_errmsg_exit "Key length is different for Proper_pubkey.pem and input_Dummy_key.der" \
                     $ERRCODE_PEM_AND_DER_KEYLEN_DIFFERENT
  fi

  return $key_index
}

#######################################
# Replace the modulus in Dummy_key.der.
# Globals:
#   SUPPORTED_RSA_KEY_LENGTH
#   TMPFILE_MOD_TXT
#   TMPFILE_MOD_BIN
#   TMPFILE_TOP_BIN
#   TMPFILE_BOT_BIN
#   TMPFILE_SIZE_TOP_BIN
#   SHELL_NAME
# Arguments:
#   File name of Proper_pubkey.pem.
#   File name of input_Dummy_key.der.
#   File name of output_Dummy_key.der.
# Outputs:
#   Writes error message to stderr
#   Writes success message to stdout
# Returns:
#   0 Success
#######################################
replace_modulus() {
  local pub_pem_file=$1
  local in_der_file=$2
  local out_der_file=$3
  local key_index
  local keylen_in_bytes
  local keylen_in_bits
  local start_line
  local end_line
  local modulus_data
  local der_file_size
  local der_bottom_size

  # Get the key length from Proper_pubkey.pem and input_Dummy_key.der
  get_key_length "$pub_pem_file" "$in_der_file"
  key_index=$?
  keylen_in_bits=${SUPPORTED_RSA_KEY_LENGTH[$key_index]}
  keylen_in_bytes=$((keylen_in_bits / 8))

  # Extract modulus from Proper_pubkey.pem
  set -e
  openssl rsa -text -pubin -in "$pub_pem_file" -noout -out $TMPFILE_MOD_TXT
  start_line=$(cat $TMPFILE_MOD_TXT | grep -n "Modulus" | awk -F ":" '{print$1}')
  end_line=$(cat $TMPFILE_MOD_TXT | grep -n "Exponent" | awk -F ":" '{print$1}')
  start_line=$((start_line + 1))
  end_line=$((end_line - 1))

  modulus_data=$(cat $TMPFILE_MOD_TXT | \
               sed -n -e $start_line,${end_line}p | \
               sed 's/ //g' | \
               sed -z 's/\n//g' | \
               sed 's/://g')

  der_file_size=$(wc -c "$in_der_file" | awk '{print $1}')
  der_bottom_size=$((der_file_size - keylen_in_bytes - TMPFILE_SIZE_TOP_BIN - 1))

  echo "$modulus_data" | xxd -p -r > $TMPFILE_MOD_BIN
  head -c $TMPFILE_SIZE_TOP_BIN "$in_der_file" > $TMPFILE_TOP_BIN
  tail -c $der_bottom_size "$in_der_file" > $TMPFILE_BOT_BIN

  # Create output_Dummy_key.der
  cat $TMPFILE_TOP_BIN $TMPFILE_MOD_BIN $TMPFILE_BOT_BIN > "$out_der_file"

  # Remove temporary files
  rm $TMPFILE_MOD_TXT $TMPFILE_MOD_BIN $TMPFILE_TOP_BIN $TMPFILE_BOT_BIN

  # This shell script is successful and writes to stdout
  echo "$SHELL_NAME version $SW_VERSION"
  echo "The supported openssl version $SUPPORTED_OPENSSL_VERSION"
  echo "$SHELL_NAME completed successfully. Key length is $keylen_in_bits bits."

  return 0
}

#######################################
# Main routine.
# Globals:
#   SHELL_NAME
#   ERRCODE_INVALID_ARGMENT
# Arguments:
#   File name of Proper_pubkey.pem.
#   File name of input_Dummy_key.der.
#   File name of output_Dummy_key.der.
# Outputs:
#   Writes error message to stderr
# Returns:
#   0 Success
#######################################
main() {
  local pub_pem_file
  local in_der_file
  local out_der_file

  SHELL_NAME=$(basename "$0")
  readonly SHELL_NAME

  # Check the arguments
  if [ $# -lt 3 ]; then
    disp_errmsg_exit "Specification of the argument is insufficient" \
                     $ERRCODE_INVALID_ARGMENT
  fi

  pub_pem_file=$1
  in_der_file=$2
  out_der_file=$3

  # Pre processing
  set -o pipefail
  check_openssl_version
  check_arguments "$pub_pem_file" "$in_der_file" "$out_der_file"
  check_format "$pub_pem_file" "$in_der_file"

  # Main processing
  replace_modulus "$pub_pem_file" "$in_der_file" "$out_der_file"

  return 0
}

main "$@"
