###############################################################################
# Copyright (c) 2015-2018, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################

# Filename - globaldefines.py
# Description - This file contains global defines used in the secure
#               boot utility
####################################################################

# RSA Modulus size = RSA signature size
RSA_PRIVATE_KEY_SIZE_IN_BITS_2048BIT = 2048
RSA_PRIVATE_KEY_SIZE_IN_BITS_3072BIT = 3072
RSA_PRIVATE_KEY_SIZE_IN_BITS_4096BIT = 4096

RSA_PRIVATE_KEY_SIZE_IN_BYTES_2048BIT = 256
RSA_PRIVATE_KEY_SIZE_IN_BYTES_3072BIT = 384
RSA_PRIVATE_KEY_SIZE_IN_BYTES_4096BIT = 512


# certificate output file prefix
Cert_FileName = "Cert"
# certificate output file suffix
Cert_FileExtBin = ".bin"
Cert_FileExtTxt = ".txt"

#so name
SBU_CRYPTO_LIB_DIR = "lib"
SBU_CRYPTO_LIB_Name = SBU_CRYPTO_LIB_DIR + "/" + "libsbdu.so"


# Defines for project endianity
################################
CERT_IN_LITTLE_ENDIAN = 0
CERT_IN_BIG_ENDIAN = 1

# Definition for debug mode
###########################
DEBUG_MODE_OFF = 0
DEBUG_MODE_ON = 1
DEBUG_MODE = DEBUG_MODE_OFF

# Definitions for list of configurables parameters
##################################################
LIST_OF_CONF_PARAMS = ["CERT_ENDIANITY","RSA_ALGORITHM","CERT_VERSION_MAJOR","CERT_VERSION_MINOR","NUM_OF_REVOCATION_COUNTERS_SUPPORT"]

# Key number
KEY_NUMBER_1KEY = 1
KEY_NUMBER_4KEY = 4
