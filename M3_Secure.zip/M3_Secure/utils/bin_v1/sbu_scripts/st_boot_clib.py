#!/usr/bin/env python3
# -*- coding: utf-8 -*-
###############################################################################
# Copyright (c) 2015-2020, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################
import os
import sys
from ctypes import *
import subprocess
import tempfile
import cgi

from global_defines import *

##########################################
# Constant definition
##########################################
#### Common definition(CLibrary)
SBU_OK                           = 0
SBU_NG                           = -1

KEYPAIR_SIZE                     = 1792
KEYPAIR_SIZE_3KBIT               = 2576
KEYPAIR_SIZE_4KBIT               = 3344

PUBKEY_SIZE                      = 480
PUBKEY_SIZE_3KBIT                = 640
PUBKEY_SIZE_4KBIT                = 832

KEY_CERT_SIZE                    = 588
KEY_CERT_SIZE_1KEY3KBIT          = 844
KEY_CERT_SIZE_1KEY4KBIT          = 1100
KEY_CERT_SIZE_4KEY2KBIT          = 2184
KEY_CERT_SIZE_4KEY3KBIT          = 3208
KEY_CERT_SIZE_4KEY4KBIT          = 4232

CONTENT_CERT_BASE_SIZE_2KBIT     = 564
CONTENT_CERT_BASE_SIZE_3KBIT     = 820
CONTENT_CERT_BASE_SIZE_4KBIT     = 1076
CONTENT_CERT_ADDFILE_SIZE        = 52
PASS_PHRASE_SIZE                 = 64

KEY_HASH_SIZE                    = 96
ZERO_BIT_HASH_SIZE               = 8
ENC_KEY_LEN                      = 80

KEY_NUM                          = 4
PROGRAM_IMAGE_BLOCK_SIZE         = 16
AES_IV_SIZE                      = 16

CTYPE_DISABLE_ENCRYPT            = 0
CTYPE_ENABLE_ENCRYPT             = 1
CTYPE_ENABLE_ENCRYPT_AND_PROGRAM = 2

#### Constant is used in the script.
FILENAME_ENCPYPT_SUFFIX        = '_enc.bin'
FILENAME_IV_SUFFIX             = '_iv.bin'

# Path
#LOCATION_DIR           = sys.path[0] + "/"
PATH_SDBU              = SBU_CRYPTO_LIB_Name

# Root Private Key size.
PRIVATE_KEY_ERR = 0
PRIVATE_KEY_2K  = RSA_PRIVATE_KEY_SIZE_IN_BITS_2048BIT
PRIVATE_KEY_3K  = RSA_PRIVATE_KEY_SIZE_IN_BITS_3072BIT
PRIVATE_KEY_4K  = RSA_PRIVATE_KEY_SIZE_IN_BITS_4096BIT


##########################################
# structure(C library IF)
##########################################
#### Create Key Certtification
class InOutKeyCert(Structure):
    _fields_ = [
    ('CertKeypair',           c_ubyte * KEYPAIR_SIZE),
    ('CertKeypairSize',       c_uint),
    ('CertKeypairPass',       c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p)
    ]

class InOutKeyCert_1Key3Kbit(Structure):
    _fields_ = [
    ('CertKeypair',           c_ubyte * KEYPAIR_SIZE_3KBIT),
    ('CertKeypairSize',       c_uint),
    ('CertKeypairPass',       c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE_3KBIT),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p)
    ]

class InOutKeyCert_1Key4Kbit(Structure):
    _fields_ = [
    ('CertKeypair',           c_ubyte * KEYPAIR_SIZE_4KBIT),
    ('CertKeypairSize',       c_uint),
    ('CertKeypairPass',       c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE_4KBIT),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p)
    ]

class InOutKeyCert_4Key2Kbit(Structure):
    _fields_ = [
    ('CertKeypair',           (c_ubyte * KEYPAIR_SIZE) * KEY_NUM),
    ('CertKeypairSize',       c_uint * KEY_NUM),
    ('CertKeypairPass',       (c_ubyte * PASS_PHRASE_SIZE) * KEY_NUM),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p * KEY_NUM)
    ]

class InOutKeyCert_4Key3Kbit(Structure):
    _fields_ = [
    ('CertKeypair',           (c_ubyte * KEYPAIR_SIZE_3KBIT) * KEY_NUM),
    ('CertKeypairSize',       c_uint * KEY_NUM),
    ('CertKeypairPass',       (c_ubyte * PASS_PHRASE_SIZE) * KEY_NUM),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE_3KBIT),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p * KEY_NUM)
    ]

class InOutKeyCert_4Key4Kbit(Structure):
    _fields_ = [
    ('CertKeypair',           (c_ubyte * KEYPAIR_SIZE_4KBIT) * KEY_NUM),
    ('CertKeypairSize',       c_uint * KEY_NUM),
    ('CertKeypairPass',       (c_ubyte * PASS_PHRASE_SIZE) * KEY_NUM),
    ('NvcounterId',           c_uint),
    ('NvcounterVal',          c_uint),
    ('NextCertPubKey',        c_ubyte * PUBKEY_SIZE_4KBIT),
    ('NextCertPubKeySize',    c_uint),
    ('pDigest',               c_char_p * KEY_NUM)
    ]

#### Create Content Certtification
class InOutContentCertImageTable(Structure):
    _fields_ = [
    ('MemLordAddr64bit',    c_ulonglong),
    ('FlashStoreAddr64bit', c_ulonglong),
    ('ImageBinarySize',     c_uint),
    ('pImageBinary',        c_char_p),
    ('pImageBinaryEnc',     c_char_p),
    ('AesIVData',           c_ubyte * AES_IV_SIZE)
    ]

class InOutContentCert(Structure):
    _fields_ = [
    ('CertKeypair',            c_ubyte * KEYPAIR_SIZE),
    ('CertKeypairSize',        c_uint),
    ('CertKeypairPass',        c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',            c_uint),
    ('NvcounterVal',           c_uint),
    ('CreationType',           c_uint),
    ('AesEncKey',              c_ubyte * ENC_KEY_LEN),
    ('ImageBinaryNum',         c_uint),
    ('pContentCertImageTable', c_void_p),
    ('pDigest',                c_char_p)
    ]

class InOutContentCert_3Kbit(Structure):
    _fields_ = [
    ('CertKeypair',            c_ubyte * KEYPAIR_SIZE_3KBIT),
    ('CertKeypairSize',        c_uint),
    ('CertKeypairPass',        c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',            c_uint),
    ('NvcounterVal',           c_uint),
    ('CreationType',           c_uint),
    ('AesEncKey',              c_ubyte * ENC_KEY_LEN),
    ('ImageBinaryNum',         c_uint),
    ('pContentCertImageTable', c_void_p),
    ('pDigest',                c_char_p)
    ]

class InOutContentCert_4Kbit(Structure):
    _fields_ = [
    ('CertKeypair',            c_ubyte * KEYPAIR_SIZE_4KBIT),
    ('CertKeypairSize',        c_uint),
    ('CertKeypairPass',        c_ubyte * PASS_PHRASE_SIZE),
    ('NvcounterId',            c_uint),
    ('NvcounterVal',           c_uint),
    ('CreationType',           c_uint),
    ('AesEncKey',              c_ubyte * ENC_KEY_LEN),
    ('ImageBinaryNum',         c_uint),
    ('pContentCertImageTable', c_void_p),
    ('pDigest',                c_char_p)
    ]

#### Create Public Key Hash
class InputHbkGen(Structure):
	_fields_ = [
    ('PubKey',                c_ubyte * PUBKEY_SIZE),
	('PubKeySize',            c_uint),
	('CertPkg',               c_ubyte * KEY_CERT_SIZE)
    ]

class InputHbkGen_1Key3Kbit(Structure):
	_fields_ = [
    ('PubKey',                c_ubyte * PUBKEY_SIZE_3KBIT),
	('PubKeySize',            c_uint),
	('CertPkg',               c_ubyte * KEY_CERT_SIZE_1KEY3KBIT)
    ]

class InputHbkGen_1Key4Kbit(Structure):
	_fields_ = [
    ('PubKey',                c_ubyte * PUBKEY_SIZE_4KBIT),
	('PubKeySize',            c_uint),
	('CertPkg',               c_ubyte * KEY_CERT_SIZE_1KEY4KBIT)
    ]

class InputHbkGen_4Key2Kbit(Structure):
	_fields_ = [
	('CertPkg',               c_ubyte * KEY_CERT_SIZE_4KEY2KBIT)
    ]

class InputHbkGen_4Key3Kbit(Structure):
	_fields_ = [
	('CertPkg',               c_ubyte * KEY_CERT_SIZE_4KEY3KBIT)
    ]

class InputHbkGen_4Key4Kbit(Structure):
	_fields_ = [
	('CertPkg',               c_ubyte * KEY_CERT_SIZE_4KEY4KBIT)
    ]

class OutputKeyHash(Structure):
    _fields_ = [
	('KeyHash',               c_ubyte * KEY_HASH_SIZE),
	('ZeroBitHash',           c_ubyte * ZERO_BIT_HASH_SIZE)
    ]


##########################################
# definition of the C library API.
##########################################
STL  = CDLL(PATH_SDBU)

# STL_CreateKeyCert()
STL.STL_CreateKeyCert.restype = c_int
STL.STL_CreateKeyCert.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateKeyCert_1Key3Kbit()
STL.STL_CreateKeyCert_1Key3Kbit.restype = c_int
STL.STL_CreateKeyCert_1Key3Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateKeyCert_1Key4Kbit()
STL.STL_CreateKeyCert_1Key4Kbit.restype = c_int
STL.STL_CreateKeyCert_1Key4Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateKeyCert_4Key2Kbit()
STL.STL_CreateKeyCert_4Key2Kbit.restype = c_int
STL.STL_CreateKeyCert_4Key2Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateKeyCert_4Key3Kbit()
STL.STL_CreateKeyCert_4Key3Kbit.restype = c_int
STL.STL_CreateKeyCert_4Key3Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateKeyCert_4Key4Kbit()
STL.STL_CreateKeyCert_4Key4Kbit.restype = c_int
STL.STL_CreateKeyCert_4Key4Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_CreateContentCert()
STL.STL_CreateContentCert.restype = c_int
STL.STL_CreateContentCert.argtypes = [c_void_p, c_char_p, c_void_p]

# STL_CreateContentCert_3Kbit()
STL.STL_CreateContentCert_3Kbit.restype = c_int
STL.STL_CreateContentCert_3Kbit.argtypes = [c_void_p, c_char_p, c_void_p]

# STL_CreateContentCert_4Kbit()
STL.STL_CreateContentCert_4Kbit.restype = c_int
STL.STL_CreateContentCert_4Kbit.argtypes = [c_void_p, c_char_p, c_void_p]

# STL_HbkGenerateHash()
STL.STL_HbkGenerateHash.restype = c_int
STL.STL_HbkGenerateHash.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_HbkGenerateHash_1Key3Kbit()
STL.STL_HbkGenerateHash_1Key3Kbit.restype = c_int
STL.STL_HbkGenerateHash_1Key3Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_HbkGenerateHash_1Key4Kbit()
STL.STL_HbkGenerateHash_1Key4Kbit.restype = c_int
STL.STL_HbkGenerateHash_1Key4Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_HbkGenerateHash_4Key2Kbit()
STL.STL_HbkGenerateHash_4Key2Kbit.restype = c_int
STL.STL_HbkGenerateHash_4Key2Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_HbkGenerateHash_4Key3Kbit()
STL.STL_HbkGenerateHash_4Key3Kbit.restype = c_int
STL.STL_HbkGenerateHash_4Key3Kbit.argtypes = [c_void_p, c_void_p, c_void_p]

# STL_HbkGenerateHash_4Key4Kbit()
STL.STL_HbkGenerateHash_4Key4Kbit.restype = c_int
STL.STL_HbkGenerateHash_4Key4Kbit.argtypes = [c_void_p, c_void_p, c_void_p]



##########################################
# function
##########################################
#### Retrieve the Key length from the pem file.
def GetKeyLengthFromPemFile(PrivateKeyPath, PrivateKeyPassPath):
    OPENSSL_CMD = "openssl rsa -text -noout -in"
    FILTER_CMD = "awk 'NR==1{print(substr($3, 2))}'"
    if (len(PrivateKeyPassPath) != 0):
        PASS_CMD = "-passin file:"
        shellCmd = "%s %s %s%s | %s" % (OPENSSL_CMD, PrivateKeyPath,PASS_CMD,
                                            PrivateKeyPassPath, FILTER_CMD)
    else:
        shellCmd = "%s %s | %s" % (OPENSSL_CMD, PrivateKeyPath, FILTER_CMD)
    try:
        keyLenStr = subprocess.check_output(shellCmd, shell=True)
        keyLen = int(keyLenStr)
    except ValueError:
        keyLen = PRIVATE_KEY_ERR
    return keyLen


#### Retrieve the Key length from the Public Key pem file.
def GetPublicKeyLengthFromPemFile(PubKeyPath):
    OPENSSL_CMD = "openssl rsa -text -noout -pubin -in"
    FILTER_CMD = "awk 'NR==1{print(substr($3, 2))}'"
    shellCmd = "%s %s | %s" % (OPENSSL_CMD, PubKeyPath, FILTER_CMD)
    try:
        keyLenStr = subprocess.check_output(shellCmd, shell=True)
        keyLen = int(keyLenStr)
    except ValueError:
        keyLen = PRIVATE_KEY_ERR
    return keyLen


#### key file read
def ReadKeyFile(FileName, BuffSize):
    ErrMsg = ''
    result = True
    KeyArray = 0
    Size = 0

    try:
        with open(FileName, 'rb') as fd:
            FileData = fd.read()

        Size = len(FileData)
        if BuffSize < Size:
            result = False
            ErrMsg = 'Invalid file size. ' + FileName + ' size:' + str(Size)
        else:
            KeyArray = create_string_buffer(FileData, BuffSize)

    except IOError as Error1:
        (errno, strerror) = Error1.args
        ErrMsg = 'Error in opening file - ' + FileName
        result = False

    return result, ErrMsg, KeyArray, Size


####
def GetFileName(PathNameList):
    FileNameList = []

    for PathName in PathNameList:
        FileName = str()
        for data in reversed(bytes(PathName, 'sjis')):
            if (data != 0x5C):
                FileName = chr(data) + FileName
            else:
                break;
        FileNameList.append(FileName)

    return FileNameList


# The GetDataFromBinFile gets the data from a binary file
def GetDataFromBinFile(certFileName):
    result = True
    binStr = str()

    try:
        # Open a binary file and write the data to it
        FileObj = open(certFileName, "rb")
        binStr = FileObj.read()
        FileObj.close()

    except IOError as Error7:
        result = False
        binStr = None

    return result, binStr


#### create the encryption file name.
def CreateEncryptFileName(PathNameList):
    result = True
    ErrMsg = ''
    EncFileNameList = []

    FileNameList = GetFileName(PathNameList)
    for FileName in FileNameList:
        # Name convert Encrypt Name
        name, ext= os.path.splitext(FileName)
        FileName = name + FILENAME_ENCPYPT_SUFFIX
        EncFileNameList.append(FileName)

    return result, ErrMsg, EncFileNameList


#### create the AES IV file name.
def CreateAesIVFileName(PathNameList):
    result = True
    ErrMsg = ''
    IVFileNameList = []

    FileNameList = GetFileName(PathNameList)
    for FileName in FileNameList:
        # Name convert Encrypt Name
        name, ext= os.path.splitext(FileName)
        FileName = name + FILENAME_IV_SUFFIX
        IVFileNameList.append(FileName)

    return result, ErrMsg, IVFileNameList


#### Files to archive.
def FileArchive(FileNameList, ImageList):
    result = True
    ErrMsg = ''

    try:
        for Cnt, ImageData in enumerate(ImageList):
            FilePath = FileNameList[Cnt]
            with open( FilePath, 'wb') as fd:
                fd.write(ImageData)
                fd.close()

    except:
        result = False
        ErrMsg = 'File archive failure.'

    return result, ErrMsg


#### Check the definition of key files.
def CheckRootPrivateKey(ArgsDict):

    # Check the definition of key files.
    if ((len(ArgsDict['cert_keypair1']) != 0) and
        (ArgsDict['cert_keypair2'] is None) and
        (ArgsDict['cert_keypair3'] is None) and
        (ArgsDict['cert_keypair4'] is None)):
        #1key
        KeySize = GetKeyLengthFromPemFile(ArgsDict['cert_keypair1'],
                                            ArgsDict['cert_keypair_pwd1'])
        if KeySize != PRIVATE_KEY_ERR:
            return True, '', 1, KeySize
        else:
            return False, 'Root Private key file is abnormal.', 0, 0

    elif ((len(ArgsDict['cert_keypair1']) != 0) and
          (len(ArgsDict['cert_keypair2']) != 0) and
          (len(ArgsDict['cert_keypair3']) != 0) and
          (len(ArgsDict['cert_keypair4']) != 0)):
        # 4key
        KeySize1 = GetKeyLengthFromPemFile(ArgsDict['cert_keypair1'],
                                             ArgsDict['cert_keypair_pwd1'])
        KeySize2 = GetKeyLengthFromPemFile(ArgsDict['cert_keypair2'],
                                             ArgsDict['cert_keypair_pwd2'])
        KeySize3 = GetKeyLengthFromPemFile(ArgsDict['cert_keypair3'],
                                             ArgsDict['cert_keypair_pwd3'])
        KeySize4 = GetKeyLengthFromPemFile(ArgsDict['cert_keypair4'],
                                             ArgsDict['cert_keypair_pwd4'])
        if ((KeySize1 != PRIVATE_KEY_ERR) and
            (KeySize1 == KeySize2) and
            (KeySize1 == KeySize3) and
            (KeySize1 == KeySize4)) :
            return True, '', 4, KeySize
        else:
            return False, 'Root Private key file is abnormal.', 0, 0

    else:
        return False, 'Root Private key file is abnormal.', 0, 0


####
def SetKeyfileForKeyCertificate(InOutKeyCertData, KeyNum, KeyPairSize, ArgsDict):
    result = True
    ErrMsg = ''

    # read Root private key file
    if KeyNum == 1:
        # 1key
        result, ErrMsg, CertKeypair, CertKeypairSize = ReadKeyFile(
                                    ArgsDict['cert_keypair1'], KeyPairSize
                                    )
        if result != True:
            return result, ErrMsg
        for Cnt in range(CertKeypairSize):
            InOutKeyCertData.CertKeypair[Cnt] = CertKeypair.raw[Cnt]
        InOutKeyCertData.CertKeypairSize = CertKeypairSize

        # set password
        if len(ArgsDict['cert_keypair_pwd1']) != 0:
            result, ErrMsg, Pass, PassSize = ReadKeyFile(ArgsDict['cert_keypair_pwd1'], PASS_PHRASE_SIZE)
            if ((result == True) and (PassSize < PASS_PHRASE_SIZE)):
                for Cnt in range(PassSize):
                    InOutKeyCertData.CertKeypairPass[Cnt] = Pass.raw[Cnt]
            else:
                result = False
                ErrMsg = 'PASSWORD_ROOT_PRIVATE_KEY is too long.'
    else:
        # 4key
        PathKey = [ArgsDict['cert_keypair1'], ArgsDict['cert_keypair2'],
                   ArgsDict['cert_keypair3'], ArgsDict['cert_keypair4']]
        Password = [ArgsDict['cert_keypair_pwd1'], ArgsDict['cert_keypair_pwd2'],
                    ArgsDict['cert_keypair_pwd3'], ArgsDict['cert_keypair_pwd4']]
        for KeyCnt in range(KEY_NUM):
            result, ErrMsg, CertKeypair, CertKeypairSize \
                                = ReadKeyFile(PathKey[KeyCnt], KeyPairSize)
            if result != True:
                return result, ErrMsg
            for Cnt in range(CertKeypairSize):
                InOutKeyCertData.CertKeypair[KeyCnt][Cnt] =CertKeypair.raw[Cnt]
            InOutKeyCertData.CertKeypairSize[KeyCnt] = CertKeypairSize

            # set password
            if len(Password[KeyCnt]) != 0:
                result, ErrMsg, Pass, PassSize = ReadKeyFile(Password[KeyCnt], PASS_PHRASE_SIZE)
                if ((result == True) and (PassSize < PASS_PHRASE_SIZE)):
                    for Cnt in range(PassSize):
                        InOutKeyCertData.CertKeypairPass[KeyCnt][Cnt] = Pass.raw[Cnt]
                else:
                    result = False
                    ErrMsg = 'PASSWORD_ROOT_PRIVATE_KEY{0} is too long.'.format(KeyCnt+1)
                    break

    return result, ErrMsg


#### Retrieve the data from the definition of the key file.
def GetDataForKeyCertificate(ArgsDict):
    result = True
    ErrMsg = ''
    KeyPairSize = 0
    PubkeySize = 0
    CertSize = 0
    InOutKeyCertData = None
    Function = None

    # Get the root private key size.
    result, ErrMsg, KeyNum, KeySize = CheckRootPrivateKey(ArgsDict)
    if result == True:
        if KeyNum == 1:
            # 1key
            if KeySize == PRIVATE_KEY_2K:
                KeyPairSize = KEYPAIR_SIZE
                PubkeySize = PUBKEY_SIZE
                CertSize = KEY_CERT_SIZE
                InOutKeyCertData = InOutKeyCert()
                Function = STL.STL_CreateKeyCert

            elif KeySize == PRIVATE_KEY_3K:
                KeyPairSize = KEYPAIR_SIZE_3KBIT
                PubkeySize = PUBKEY_SIZE_3KBIT
                CertSize = KEY_CERT_SIZE_1KEY3KBIT
                InOutKeyCertData = InOutKeyCert_1Key3Kbit()
                Function = STL.STL_CreateKeyCert_1Key3Kbit

            elif KeySize == PRIVATE_KEY_4K:
                KeyPairSize = KEYPAIR_SIZE_4KBIT
                PubkeySize = PUBKEY_SIZE_4KBIT
                CertSize = KEY_CERT_SIZE_1KEY4KBIT
                InOutKeyCertData = InOutKeyCert_1Key4Kbit()
                Function = STL.STL_CreateKeyCert_1Key4Kbit

            else:
                result = False
                ErrMsg = 'Root Private key file definition not supported.'
        else:
            # 4key
            if KeySize == PRIVATE_KEY_2K:
                KeyPairSize = KEYPAIR_SIZE
                PubkeySize = PUBKEY_SIZE
                CertSize = KEY_CERT_SIZE_4KEY2KBIT
                InOutKeyCertData = InOutKeyCert_4Key2Kbit()
                Function = STL.STL_CreateKeyCert_4Key2Kbit

            elif KeySize == PRIVATE_KEY_3K:
                KeyPairSize = KEYPAIR_SIZE_3KBIT
                PubkeySize = PUBKEY_SIZE_3KBIT
                CertSize = KEY_CERT_SIZE_4KEY3KBIT
                InOutKeyCertData = InOutKeyCert_4Key3Kbit()
                Function = STL.STL_CreateKeyCert_4Key3Kbit

            elif KeySize == PRIVATE_KEY_4K:
                KeyPairSize = KEYPAIR_SIZE_4KBIT
                PubkeySize = PUBKEY_SIZE_4KBIT
                CertSize = KEY_CERT_SIZE_4KEY4KBIT
                InOutKeyCertData = InOutKeyCert_4Key4Kbit()
                Function = STL.STL_CreateKeyCert_4Key4Kbit

            else:
                result = False
                ErrMsg = 'Root Private key file definition not supported.'

        if result == True:
            # read Root private key file
            result, ErrMsg = SetKeyfileForKeyCertificate(
                                InOutKeyCertData, KeyNum, KeyPairSize, ArgsDict)

    return (result, ErrMsg, PubkeySize, CertSize, InOutKeyCertData, Function, KeySize, KeyNum)


#### Create KeyCertificate
def CreateKeyCert(ArgsDict):
    #check OpenSSL version
    result, ErrMsg \
            =Checkopenssl()
    if result != True:
        return result, ErrMsg, '0', None

    # Retrieve the data from the definition of the key file.
    result, ErrMsg, PubkeySize, CertSize, InOutKeyCertData, Function, KeySize, KeyNum \
                                                = GetDataForKeyCertificate(ArgsDict)
    if result != True:
        return result, ErrMsg, '0', None

    # read SW public key file
    result, ErrMsg, NextCertPubKeyData, NextCertPubKeySizeData \
                            = ReadKeyFile(ArgsDict['next_cert_pubkey'], PubkeySize)
    if result != True:
        return result, ErrMsg, '0', None

    # Set InOutKeyCert
    for Cnt in range(PubkeySize):
        InOutKeyCertData.NextCertPubKey[Cnt] = NextCertPubKeyData.raw[Cnt]
    InOutKeyCertData.NextCertPubKeySize = NextCertPubKeySizeData
    InOutKeyCertData.NvcounterId = ArgsDict['nvcounter_id']
    InOutKeyCertData.NvcounterVal = ArgsDict['nvcounter_val']

    # Set Digest Buffer
    if ArgsDict['hash-out1'] is not None:
        DigestList = list()
        KeySizeInByte = int(KeySize / 8)
        if KeyNum == 1:
            DigestList.append(create_string_buffer(KeySizeInByte))
            InOutKeyCertData.pDigest = cast(DigestList[0], c_char_p)
        else:
            for Cnt in range(KeyNum):
                DigestList.append(create_string_buffer(KeySizeInByte))
                InOutKeyCertData.pDigest[Cnt] = cast(DigestList[Cnt], c_char_p)
    else:
        DigestList = None
        if KeyNum == 1:
            InOutKeyCertData.pDigest = None
        else:
            for Cnt in range(KeyNum):
                InOutKeyCertData.pDigest[Cnt] = None

    # Set the arguments of KeyCertificate
    CertPkg = create_string_buffer(CertSize)
    CertPkgData = cast(CertPkg, c_char_p)
    Res = c_uint()

    ret = Function(byref(InOutKeyCertData), CertPkgData, byref(Res))
    if ret == SBU_OK:
        return True, '', CertPkg, DigestList
    else:
        return (False,
                '{0}() failed. Result={1}'.format(Function.__name__,
                                                  Res.value),
                '0', None)


#### Retrieve the data from the definition of the key file.
def GetDataForContentCertificate(ArgsDict, FileNum, SWPrivateKeyFileName, SWPassFileName):
    result = True
    ErrMsg = ''
    CertKeyPairSize = ''
    CertSize = 0
    InOutContentCertData = None
    Function = None
    RootPrivateKeySize = 0

    # Get the root private key size.
    result, ErrMsg, dummy, RootPrivateKeySize = CheckRootPrivateKey(ArgsDict)
    if result == True:
        # Get the SW private key size.
        SWPrivateKeySize = GetKeyLengthFromPemFile(SWPrivateKeyFileName, SWPassFileName)

        if RootPrivateKeySize == SWPrivateKeySize:
            if SWPrivateKeySize == PRIVATE_KEY_2K:
                CertSize = (CONTENT_CERT_BASE_SIZE_2KBIT
                            + (CONTENT_CERT_ADDFILE_SIZE * FileNum))
                CertKeyPairSize = KEYPAIR_SIZE
                InOutContentCertData = InOutContentCert()
                Function = STL.STL_CreateContentCert

            elif SWPrivateKeySize == PRIVATE_KEY_3K:
                CertSize = (CONTENT_CERT_BASE_SIZE_3KBIT
                            + (CONTENT_CERT_ADDFILE_SIZE * FileNum))
                CertKeyPairSize = KEYPAIR_SIZE_3KBIT
                InOutContentCertData = InOutContentCert_3Kbit()
                Function = STL.STL_CreateContentCert_3Kbit

            elif SWPrivateKeySize == PRIVATE_KEY_4K:
                CertSize = (CONTENT_CERT_BASE_SIZE_4KBIT
                            + (CONTENT_CERT_ADDFILE_SIZE * FileNum))
                CertKeyPairSize = KEYPAIR_SIZE_4KBIT
                InOutContentCertData = InOutContentCert_4Kbit()
                Function = STL.STL_CreateContentCert_4Kbit
            else:
                result = False
                ErrMsg = 'SW private key file definition not supported.'
        else:
            result = False
            ErrMsg = 'Key size of Root private key and Software private key are different.'
    return (result, ErrMsg,
            CertKeyPairSize, CertSize,
            InOutContentCertData, Function, RootPrivateKeySize)


#### Create Content Certificate
def CreateContentCert(RecList, ArgsDict):
    #check OpenSSL version
    result, ErrMsg \
            =Checkopenssl()
    if result != True:
        return result, ErrMsg, '0', None

    FileNum = len(RecList)
    PathNameList = list()
    SWPrivateKeyFileName = ArgsDict['cert_keypair1']
    SWPassFileName = ArgsDict['cert_keypair_pwd1']
    AESEncKeyFileName = ArgsDict['aes_enc_key']
    NvId = ArgsDict['nvcounter_id']
    NvVal = ArgsDict['nvcounter_val']

    # Retrieve the data from the definition of the key file.
    result, ErrMsg, CertKeyPairSize, CertSize, \
            InOutContentCertData, Function, KeySize \
            = GetDataForContentCertificate(ArgsDict, FileNum, SWPrivateKeyFileName, SWPassFileName)
    if result != True:
        return result, ErrMsg, '0', None

    # read SW private key file
    result, ErrMsg, CertKeypairData, CertKeypairSizeData \
                              = ReadKeyFile(SWPrivateKeyFileName, CertKeyPairSize)
    if result != True:
        return result, ErrMsg, '0', None

    # read Aes-Enc-Key file
    if (ArgsDict['encryption_flag'] == 1):
        result, ErrMsg, AesEncKey, AesEncKeySize \
                                = ReadKeyFile(AESEncKeyFileName, ENC_KEY_LEN)
        if result != True:
            return result, ErrMsg, '0', None
        if AesEncKeySize > ENC_KEY_LEN:
            return False, 'Code Encryption Key file(kce.txt) size is abnormal.', '0', None

    # Set InputContentCertImageTable.
    ImageBinaryEncList = []
    AesIVList = []
    InOutContentCertImageTableData = (InOutContentCertImageTable * FileNum)()
    for Cnt in range(FileNum):
        InOutContentCertImageTableData[Cnt].MemLordAddr64bit \
                                            = RecList[Cnt].get('MemLoadAddr');
        InOutContentCertImageTableData[Cnt].FlashStoreAddr64bit \
                                            = RecList[Cnt].get('MemLoadAddr');
        ImageBinarySize = len(RecList[Cnt].get('Image'))
        InOutContentCertImageTableData[Cnt].ImageBinarySize = ImageBinarySize
        InOutContentCertImageTableData[Cnt].pImageBinary \
                                    = cast(RecList[Cnt].get('Image'), c_char_p)
        # Encrypted data size is a multiple of 16
        if 0 != (ImageBinarySize % PROGRAM_IMAGE_BLOCK_SIZE):
            EncImageBinarySize = ((ImageBinarySize
                  // PROGRAM_IMAGE_BLOCK_SIZE) + 1 ) * PROGRAM_IMAGE_BLOCK_SIZE
        else:
            EncImageBinarySize = ImageBinarySize
        ImageBinaryEnc = create_string_buffer(EncImageBinarySize)
        ImageBinaryEncList.append(ImageBinaryEnc)
        InOutContentCertImageTableData[Cnt].pImageBinaryEnc \
                        = cast(ImageBinaryEnc, c_char_p)
        PathNameList.append(RecList[Cnt].get('ImgName'))
        # AesIV data buffer into List
        AesIVList.append(InOutContentCertImageTableData[Cnt].AesIVData)

    # Set InputContentCert
    for Cnt in range(CertKeyPairSize):
        InOutContentCertData.CertKeypair[Cnt] = CertKeypairData.raw[Cnt]
    InOutContentCertData.CertKeypairSize = CertKeypairSizeData

    if len(SWPassFileName) != 0:
        result, ErrMsg, Pass, PassSize = ReadKeyFile(SWPassFileName, PASS_PHRASE_SIZE)
        if ((result == True) and (PassSize < PASS_PHRASE_SIZE)):
            for Cnt in range(PassSize):
                InOutContentCertData.CertKeypairPass[Cnt] = Pass.raw[Cnt]
        else:
            return (False, 'PASSWORD_SW_PRIVATE_KEYn is too long.', '0', None)

    InOutContentCertData.NvcounterId = NvId
    InOutContentCertData.NvcounterVal = NvVal
    if (ArgsDict['encryption_flag'] == 0):
        CreationType = CTYPE_DISABLE_ENCRYPT
    else:
        CreationType = CTYPE_ENABLE_ENCRYPT_AND_PROGRAM
        for Cnt in range(AesEncKeySize):
            InOutContentCertData.AesEncKey[Cnt] = AesEncKey.raw[Cnt]
    InOutContentCertData.CreationType = CreationType
    InOutContentCertData.ImageBinaryNum = c_uint(FileNum)
    InOutContentCertData.pContentCertImageTable \
                               = cast(InOutContentCertImageTableData, c_void_p)

    # Set digest buffer
    if ArgsDict['hash-out1'] is not None:
        KeySizeInByte = int(KeySize / 8)
        DigestBuffer = create_string_buffer(KeySizeInByte)
        InOutContentCertData.pDigest = cast(DigestBuffer, c_char_p)
    else:
        DigestBuffer = None
        InOutContentCertData.pDigest = None


    # Set the arguments of STL_CreateContentCert_xxx
    CertPkg = create_string_buffer(CertSize)
    #CertPkgSizeData = c_uint(len(CertPkg))
    CertPkgData = cast(CertPkg, c_char_p)
    Res = c_uint()

    ret = Function(byref(InOutContentCertData), CertPkgData, byref(Res))
    if ret == SBU_OK:
        if ArgsDict['aes_iv_get'] == True and \
                            CreationType != CTYPE_DISABLE_ENCRYPT:
            # AES IV save to file
            # get the iv file name.
            result, ErrMsg, AesIVFileNameList \
                                 = CreateAesIVFileName(PathNameList)
            if result != True:
                return result, ErrMsg, '0', None

            result, ErrMsg = FileArchive(AesIVFileNameList, AesIVList)
            if result != True:
                return result, ErrMsg, '0', None
        if CreationType == CTYPE_ENABLE_ENCRYPT_AND_PROGRAM:
            # Files to archive
            # get the encryption file name.
            result, ErrMsg, EncFileNameList \
                                 = CreateEncryptFileName(PathNameList)
            if result != True:
                return result, ErrMsg, '0', None

            result, ErrMsg = FileArchive(EncFileNameList, ImageBinaryEncList)
            if result != True:
                return result, ErrMsg, '0', None
        return True, '', CertPkg, DigestBuffer
    else:
        return (False,
                '{0}() failed. Result={1}'.format(Function.__name__,Res.value),
                '0', None)



#### Retrieve the data from the definition of the key file.
def GetDataForHbkHash(KeyFilePath, CertFilePath):
    result = True
    ErrMsg = ''
    KeyPairSize = 0
    PubkeySize = 0
    CertSize = 0
    InputHbkGenData = None
    Function = None

    if KeyFilePath is not None:
        KeyNum   = 1
        KeySize  = GetPublicKeyLengthFromPemFile(KeyFilePath)
        CertData = None
        CertSize = 0
    elif CertFilePath is not None:
        result, CertData = GetDataFromBinFile(CertFilePath)
        CertSize = len(CertData)
        if result == True:
            if CertSize == KEY_CERT_SIZE:
                KeyNum = 1
                KeySize = PRIVATE_KEY_2K
            elif CertSize == KEY_CERT_SIZE_1KEY3KBIT:
                KeyNum = 1
                KeySize = PRIVATE_KEY_3K
            elif CertSize == KEY_CERT_SIZE_1KEY4KBIT:
                KeyNum = 1
                KeySize = PRIVATE_KEY_4K
            elif CertSize == KEY_CERT_SIZE_4KEY2KBIT:
                KeyNum = 4
                KeySize = PRIVATE_KEY_2K
            elif CertSize == KEY_CERT_SIZE_4KEY3KBIT:
                KeyNum = 4
                KeySize = PRIVATE_KEY_3K
            elif CertSize == KEY_CERT_SIZE_4KEY4KBIT:
                KeyNum = 4
                KeySize = PRIVATE_KEY_4K
            else:
                return (False, 'KeyCertificate has illegal size.', 0, 0, 0, 0, 0)
        else:
            return (False, 'KeyCertificate file read error.', 0, 0, 0, 0, 0)
    else:
        return (False, 'Both PublicKey and KeyCertificate are None.', 0, 0, 0, 0, 0)


    if result == True:
        if KeyNum == 1:
            # 1key
            if KeySize == PRIVATE_KEY_2K:
                if CertSize == 0: PubkeySize = PUBKEY_SIZE
                InputHbkGenData = InputHbkGen()
                Function = STL.STL_HbkGenerateHash

            elif KeySize == PRIVATE_KEY_3K:
                if CertSize == 0: PubkeySize = PUBKEY_SIZE_3KBIT
                InputHbkGenData = InputHbkGen_1Key3Kbit()
                Function = STL.STL_HbkGenerateHash_1Key3Kbit

            elif KeySize == PRIVATE_KEY_4K:
                if CertSize == 0: PubkeySize = PUBKEY_SIZE_4KBIT
                InputHbkGenData = InputHbkGen_1Key4Kbit()
                Function = STL.STL_HbkGenerateHash_1Key4Kbit

            else:
                return (False, 'Public key file definition not supported.', 0, 0, 0, 0, 0)
        else:
            # 4key
            if KeySize == PRIVATE_KEY_2K:
                InputHbkGenData = InputHbkGen_4Key2Kbit()
                Function = STL.STL_HbkGenerateHash_4Key2Kbit

            elif KeySize == PRIVATE_KEY_3K:
                InputHbkGenData = InputHbkGen_4Key3Kbit()
                Function = STL.STL_HbkGenerateHash_4Key3Kbit

            elif KeySize == PRIVATE_KEY_4K:
                InputHbkGenData = InputHbkGen_4Key4Kbit()
                Function = STL.STL_HbkGenerateHash_4Key4Kbit

            else:
                return (False, 'Public key file definition not supported.', 0, 0, 0, 0, 0)

    return (result, ErrMsg, PubkeySize, CertSize, CertData, InputHbkGenData, Function)


#### Create HBK Hash
def CreateHbkHash(KeyFilePath, CertFilePath):
    #check OpenSSL version
    result, ErrMsg \
            =Checkopenssl()
    if result != True:
        return result, ErrMsg, '0', '0'

    # Retrieve the data from the definition of the key file.
    result, ErrMsg, PubKeySize, CertSize, CertData, InputHbkGenData, Function \
                                    = GetDataForHbkHash(KeyFilePath, CertFilePath)
    if result != True:
        return result, ErrMsg, '0', '0'

    # read SW public key file
    if PubKeySize != 0:
        result, ErrMsg, PubKeyData, PubKeySizeData \
                            = ReadKeyFile(KeyFilePath, PubKeySize)
        if result != True:
            return result, ErrMsg, '0', '0'

    # Set InputHbkGenData
    if PubKeySize != 0:
        for Cnt in range(PubKeySize):
            InputHbkGenData.PubKey[Cnt] = PubKeyData.raw[Cnt]
        InputHbkGenData.PubKeySize = PubKeySizeData
    else:
        for Cnt in range(CertSize):
            InputHbkGenData.CertPkg[Cnt] = CertData[Cnt]

    # Set the arguments of KeyCertificate
    HbkHash = OutputKeyHash()
    Res = c_uint()

    ret = Function(byref(InputHbkGenData), byref(HbkHash), byref(Res))
    if ret == SBU_OK:
        KeyHashBuff = (c_ubyte * (KEY_HASH_SIZE + 1))()
        for Cnt in range(KEY_HASH_SIZE):
            KeyHashBuff[Cnt] = HbkHash.KeyHash[Cnt]

        ZeroBitHashBuff = (c_ubyte * (ZERO_BIT_HASH_SIZE + 1))()
        for Cnt in range(ZERO_BIT_HASH_SIZE):
            ZeroBitHashBuff[Cnt] = HbkHash.ZeroBitHash[Cnt]

        return True, '', KeyHashBuff, ZeroBitHashBuff
    else:
        return (False,
                '{0}() failed. Result={1}'.format(Function.__name__,
                                                  Res.value),
                '0', '0')

#### Check OpenSSL Version
def Checkopenssl():
    result = True
    ErrMsg = ''
    Openssl_Version = 111
    OPENSSL_CMD = "openssl version"
    FILTER_CMD = "awk 'NR==1{print(substr($2, 1, 5))}' | sed -e 's/[^0-9]//g'"
    shellCmd = "%s | %s" % (OPENSSL_CMD, FILTER_CMD)
    versionstr = subprocess.check_output(shellCmd, shell=True)
    version = int(versionstr)
    if (version < Openssl_Version):
        result = False
        ErrMsg = 'OpenSSL is not a supported version(Less than v1.1.1).'

    return result, ErrMsg



