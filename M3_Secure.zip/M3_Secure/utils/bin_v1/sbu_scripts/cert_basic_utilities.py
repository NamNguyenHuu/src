###############################################################################
# Copyright (c) 2015-2017, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################

import os
import sys
import re

from st_boot_clib import *


####################################################################
# Filename - cert_basic_utilites.py
# Description - This file contains basic utilities functions
####################################################################

# log functions
# Create a log file handle
def create_log_file (log_file_path):
    try:
        log_file = open(log_file_path, 'w')
    except IOError as Error7:
        (errno, strerror) = Error7.args
        print("Error in openning file - %s" %log_file_path)
        sys.exit(1)
    return log_file;

# Print (stdout) and output also to log file given text
def print_and_log (log_file, text):
    print(text)
    log_file.write(text)
    sys.stdout.flush()
    log_file.flush()

# Do synchronous write to log file
def log_sync (log_file, text):
        log_file.write(text)
        log_file.flush()

# parse configuration file according to list of parameters
def parseConfFile(FileName, listOfDefines):
    try:
        fob = open(FileName,'r')
        lines = fob.readlines()
        valuesList = list()
        for line in lines:
            for define in listOfDefines:
                if re.match(define,line):
                    tmpList=line.split("=")
                    valuesList.append(int(tmpList[len(tmpList)-1],16))
        fob.close()
    except IOError as Error1:
        (errno, strerror) = Error1.args
        print("\n Error in openning file - %s" %FileName)
        sys.exit(1)

    return valuesList
# End of parseConfFile



