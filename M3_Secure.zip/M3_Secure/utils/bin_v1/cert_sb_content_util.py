#!/usr/local/bin/python3
###############################################################################
# Copyright (c) 2015-2018, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################


import sys
import configparser
import re

# Adding the utility python scripts to the python PATH

# Definitions for paths
#######################
if sys.platform != "win32" :
    path_div = "//"
else : #platform = win32
    path_div = "\\"


CURRENT_PATH = sys.path[0]
# In case the scripts were run from current directory
CURRENT_PATH_SCRIPTS = path_div + 'sbu_scripts'

# this is the scripts local path, from where the program was called
sys.path.append(CURRENT_PATH+CURRENT_PATH_SCRIPTS)

# this is the path of the proj config file
PROJ_CFG_PATH = "src" + path_div
PROJ_CONFIG = CURRENT_PATH + path_div + ".." + path_div + PROJ_CFG_PATH + 'proj.cfg'


from global_defines import *
from cert_basic_utilities import *
from st_boot_clib import *


####################################################################
# Filename - cert_sb_content_util.py
# Description - This file contains the main functionality of the
#               secure boot utility. The utility creates a certificate
#               that is used in the secure boot process
####################################################################

########### Data Records analyzer functions ###########

# The ImageFileAnalyzer function analyzes the files list file and return a list of data records objects.
# The function does the following steps:
# Step 1 - Open the file (that contain the files list)
# Step 2 - Get each line in the file and insert it into a list of dictionaries
#          each dictionary contain:
#               image name (SW component name),
#               Memory Load address
#               Storage address of the image
def ImageFileAnalyzer(logFile, FileName):

    LinesDictList = list()

    # Open the file (that contain the files list)
    try:
        FileObj = open(FileName , "r")
        FileLines = FileObj.readlines()
        # If the file is empty the data record list will be returned empty
        if len(FileLines) == 0 :
            print_and_log(logFile, "illegal number of images = 0 !")
            sys.exit(1)
        # Get each line in the file and insert it into a list of dictionaries
        # each dictionary contain the image name (SW component name), image binary,
        # memory load address and the Flash address of the image
        for lineObj in FileLines:
            # if it is comment ignore
            if re.match(r'^#', lineObj):
                continue
            LinesDictList.append(LineAnalyzer(logFile, lineObj))

    except IOError as Error1:
        (errno, strerror) = Error1.args
        print_and_log(logFile, "\n Error in openning file - %s" %FileName)
        sys.exit(1)

    return LinesDictList
# End of ImageFileAnalyzer

# The LineAnalyzer function takes each line in the files list file and separate it
# Each line is expected to be in the following structure:
# <s/w_comp_name> <mem_load_addr> <flash_store_addr>
# The function returns a dictionary with the line data. (ImgName, Image, MemLoadAddr, FlashStoreAddr)
# In case the functions reads an illegal image address (not word alligned) an exception is raised
def LineAnalyzer(logFile, FileLine):
    try:
        LineList = FileLine.split(" ")
        ImageName = LineList[0]
        MemLoadAddr = int(LineList[1],16)
        MemLoadAddrList = createAddrList(LineList[1][2:])
        FlashStoreAddr = int(LineList[2],16)

        fd = open(ImageName, "rb")
        FileData = fd.read()
        Image = FileData
        fd.close()

    except NameError:
        print_and_log(logFile, "\n Illegal Address - not word alligned !!")
        sys.exit(1)

    except IOError as Error1:
        (errno, strerror) = Error1.args
        print_and_log(logFile, "\n Error in openning file - %s" %ImageName)
        sys.exit(1)

    return dict(ImgName = ImageName, Image = Image, MemLoadAddr = MemLoadAddr, MemLoadAddrList = MemLoadAddrList, FlashStoreAddr = FlashStoreAddr)
# End of LineAnalyzer


def createAddrList (dataStr):
    dataList = list()

    if len(dataStr)%2 == 1: #miss a zero at the beginning
        newStr = '0'+dataStr
    else:
        newStr = dataStr

    for i in range(int(len(newStr)/2)):
        dataList.append(newStr[i*2:i*2+2])
    return dataList

########### Data Records analyzer functions End ###########

########### Certificate utility functions ##########################

# The BinStrToList function takes a binary string and returns a list with HEX
# representation for the bytes
def BinStrToList(str1):
    TempList = list()
    for i in range(len(str1)):
        TempList.append("0x%02x" % str1.raw[i])

    return TempList
# End of BinStrToList

# The CreateCertBinFile opens a binary and text file and writes the certificate data into it
def CreateCertBinFile(logFile, binStr, txtList, certFileName):
    try:
        # Open a binary file and write the data to it
        FileObj = open(certFileName, "wb")
        FileObj.write(bytes(binStr.raw))
        FileObj.close()

        # Assemble the text file name (certificate + .txt)
        certFileNameTxt = certFileName[:-4] + '_' + Cert_FileName + Cert_FileExtTxt
        # Open a text file and write the data into it, in lines of 4 bytes
        FileObj = open(certFileNameTxt, "w")

        NumOfChars = len(txtList)
        if DEBUG_MODE == DEBUG_MODE_OFF:
            FileObj.write("char cert_bin_image[] = {\n")
            for i in range(NumOfChars):
                FileObj.write(txtList[i])
                if i !=  NumOfChars-1:
                    FileObj.write(',')
                if (i+1) % 4 == 0:
                    FileObj.write('\n')
            FileObj.write("}")
        if DEBUG_MODE == DEBUG_MODE_ON:
            wordsList = CreateWordsListFromBytesList(txtList)
            for obj in wordsList:
                FileObj.write(obj + ",")
                FileObj.write('\n')
        FileObj.close()
    except IOError as Error7:
        (errno, strerror) = Error7.args
        print_and_log(logFile, "Error in openning file - %s" %certFileName)
        sys.exit(1)
    return
# End of CreateCertBinFile

def CreateWordsListFromBytesList(BytesList):
    # Create words in reverse order
    wordsList = list()
    if PrjDefines[LIST_OF_CONF_PARAMS.index("CERT_ENDIANITY")] == CERT_IN_LITTLE_ENDIAN:
        length = len(BytesList)/4
        for i in range(int(length)):
            tmpStr = str()
            for j in range(4):
                byte = str()
                byte = BytesList[i*4 + 4 - j - 1]
                byte = byte[2:]
                tmpStr = tmpStr + byte
            tmpStr = '0x' + tmpStr
            wordsList.append(tmpStr)
    else:
        for i in range(len(BytesList)/4):
            tmpStr = str()
            for j in range(4):
                tmpStr = tmpStr + BytesList[i*4 + j]
            wordsList.append(tmpStr)
    return wordsList

# The function writes the hash-digest to output file
def WriteHashDigestsToFile(logFile, digest, outFilePath):
    if digest is None:
        return
    try:
        # Open a binary file and write the data to it
        FileObj = open(outFilePath, 'wb')
        FileObj.write(digest)
        FileObj.close()

    except IOError as Error7:
        (errno, strerror) = Error7.args
        print_and_log(logFile, "Error in openning file - %s" % outFilePath)
        sys.exit(1)
    return

########### certificate creation - Utility functions End ###########

# Parse given configuration file and return attributes as dictionary
def parse_config_file (config_fname, log_file):

    try:
        config_file = open(config_fname, 'r')
    except IOError as e:
        print_and_log(log_file,"Failed opening " + config_fname + " (" + e.strerror + ")\n")
        sys.exit(e.errno)

    config = configparser.ConfigParser()
    config.readfp(config_file)
    config_file.close()

    local_dict = dict()

    section_name = "CNT-CFG"
    if not config.has_section(section_name):
        log_sync(log_file, "section " + section_name + " wasn't found in cfg file\n")
        return None

    local_dict['cert_keypair1'] = config.get(section_name, 'cert-keypair')
    log_sync(log_file,"cert-keypair: " + local_dict['cert_keypair1'] + "\n")
    local_dict['cert_keypair2'] = None
    local_dict['cert_keypair3'] = None
    local_dict['cert_keypair4'] = None

    if config.has_option(section_name, 'cert-keypair-pwd'):
        local_dict['cert_keypair_pwd1'] = config.get(section_name, 'cert-keypair-pwd')
        log_sync(log_file,"cert-keypair-pwd: " + local_dict['cert_keypair_pwd1'] + "\n")
    else:
        local_dict['cert_keypair_pwd1'] = None
    local_dict['cert_keypair_pwd2'] = None
    local_dict['cert_keypair_pwd3'] = None
    local_dict['cert_keypair_pwd4'] = None

    local_dict['nvcounter_id'] = int(config.get(section_name, 'nvcounter-id'))
    if (local_dict['nvcounter_id'] != int(1) and local_dict['nvcounter_id'] != int(2)):
        log_sync(log_file, "Ilegal nvcounter-id defined - exiting\n")
        return None
    log_sync(log_file,"nvcounter-id: " + str(local_dict['nvcounter_id']) + "\n")

    local_dict['nvcounter_val'] = int(config.get(section_name, 'nvcounter-val'))
    if (local_dict['nvcounter_id'] == int(1) and local_dict['nvcounter_val'] >= int(32)):
        log_sync(log_file, "Ilegal nvcounter-val for trsuted NV-Counter defined - exiting\n")
        return None
    if (local_dict['nvcounter_id'] == int(2) and local_dict['nvcounter_val'] >= int(224)):
        log_sync(log_file, "Ilegal nvcounter-val for non-trsuted NV-Counter defined - exiting\n")
        return None
    log_sync(log_file,"nvcounter-val: " + str(local_dict['nvcounter_val']) + "\n")

    if config.has_option(section_name, 'aes-enc-key'):
        local_dict['encryption_flag'] = int(1)
        local_dict['aes_enc_key'] = config.get(section_name, 'aes-enc-key')
        log_sync(log_file,"aes-enc-key: " + local_dict['aes_enc_key'] + "\n")
    else:
        local_dict['encryption_flag'] = int(0)
        local_dict['aes_enc_key'] = None

    if config.has_option(section_name, 'enable_cm'):
        local_dict['enable_cm'] = config.get(section_name, 'enable_cm')
        if local_dict['enable_cm'] == '1':
            local_dict['enable_cm_flag'] = int(1)
        else:
            if local_dict['enable_cm'] != '0':
                log_sync(log_file, "Ilegal enable_cm value defined - exiting\n")
                return None
            local_dict['enable_cm_flag'] = int(0)
        log_sync(log_file,"enable_cm: " + local_dict['enable_cm'] + "\n")
    else:
        local_dict['enable_cm_flag'] = int(0)

    local_dict['images_table'] = config.get(section_name, 'images-table')
    log_sync(log_file,"images-table: " + local_dict['images_table'] + "\n")

    local_dict['cert-pkg'] = config.get(section_name, 'cert-pkg')
    log_sync(log_file,"cert-pkg: " + local_dict['cert-pkg'] + "\n")


    if config.has_option(section_name, 'hash-out'):
        local_dict['hash-out1'] = config.get(section_name, 'hash-out')
        log_sync(log_file,"hash-out: " + local_dict['hash-out1'] + "\n")
    else:
        local_dict['hash-out1'] = None
    local_dict['hash-out2'] = None
    local_dict['hash-out3'] = None
    local_dict['hash-out4'] = None


    local_dict['aes_iv_get'] = False
    if config.has_option(section_name, 'aes-iv-get'):
        ivout = config.get(section_name, 'aes-iv-get')
        if ivout == 'yes':
            local_dict['aes_iv_get'] = True


    return local_dict

# Parse script parameters
def parse_shell_arguments ():
    len_arg =  len(sys.argv)
    if len_arg < 2:
        print("len " + str(len_arg) + " invalid. Usage:" + sys.argv[0] + "<test configuration file>\n")
        for i in range(1,len_arg):
            print("i " + str(i) + " arg " + sys.argv[i] + "\n")
        sys.exit(1)
    config_fname = sys.argv[1]
    if len_arg == 3:
        log_fname = sys.argv[2]
    else:
        log_fname = "sb_content_cert.log"
    return config_fname, log_fname


#################################################################################
# The function analyzes the input files and creates a content certificate binary file to be used in the
# secure boot process.
#

def CreateCertUtility(sysArgsList):
    try:
        config_fname, log_fname =  parse_shell_arguments()

        log_file = create_log_file(log_fname)
        # Check the input parameters and save it to list
        ArgsDict = parse_config_file(config_fname, log_file)
        if ArgsDict == None:
               log_file.close()
               exit(1)


        print_and_log(log_file, "**** Creating Content Certificate **** ")

        RecList = ImageFileAnalyzer(log_file, ArgsDict['images_table'])

        result, resultMsg, CertPkg, DigestData = CreateContentCert(RecList, ArgsDict)
        if result == True:
            # output
            print_and_log(log_file, "\n Write the certificate to file ")
            # Write binary and text string to file
            CreateCertBinFile(log_file, CertPkg, BinStrToList(CertPkg), ArgsDict['cert-pkg'])
            # Write hash-digests
            WriteHashDigestsToFile(log_file, DigestData, ArgsDict['hash-out1'])

            print_and_log(log_file, "\n**** Certificate file creation has been completed successfully ****")
        else:
            print_and_log(log_file, "\n**** Certificate file creation failed ****")


    except IOError as Error8:
        (errno, strerror) = Error8.args
        print("I/O error(%s): %s" % (errno, strerror))
        raise
    except NameError:
        print("Unexpected error, exiting program")
        raise  # Debug info
    except ValueError:
        print("Illegal variable type")
        raise # Debug info


##################################
#       Main function
##################################

if __name__ == "__main__":

    import sys
    if sys.version_info<(3,0,0):
        print("You need python 3.0 or later to run this script")
        exit(1)

    if "-cfg_file" in sys.argv:
        PROJ_CONFIG = sys.argv[sys.argv.index("-cfg_file") + 1]
    print("Config File  - %s\n" %PROJ_CONFIG)

    # Get the project configuration values
    PrjDefines = parseConfFile(PROJ_CONFIG,LIST_OF_CONF_PARAMS)

    CreateCertUtility(sys.argv)








######################################## END OF FILE ########################################

