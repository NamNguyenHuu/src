#!/usr/local/bin/python3
###############################################################################
# Copyright (c) 2015-2018, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################

import sys
import configparser


# Adding the utility python scripts to the python PATH

# Definitions for paths
#######################
if sys.platform != "win32" :
    path_div = "//"
else : #platform = win32
    path_div = "\\"


CURRENT_PATH = sys.path[0]
# In case the scripts were run from current directory
CURRENT_PATH_SCRIPTS = path_div + 'sbu_scripts'

# this is the scripts local path, from where the program was called
sys.path.append(CURRENT_PATH+CURRENT_PATH_SCRIPTS)

# this is the path of the proj config file
PROJ_CFG_PATH = "src" + path_div
PROJ_CONFIG = CURRENT_PATH + path_div + ".." + path_div + PROJ_CFG_PATH + 'proj.cfg'

#from key_data_structures import *
from global_defines import *
from cert_basic_utilities import *
from st_boot_clib import *



####################################################################
# Filename - cert_key_util.py
# Description - This file contains the main functionality of the key
#               certificate generation.
####################################################################


########### Certificate utility functions ##########################

# The BinStrToList function takes a binary string and returns a list with HEX
# representation for the bytes
def BinStrToList(str1):
    TempList = list()
    for i in range(len(str1)):
        TempList.append("0x%02x" % str1.raw[i])

    return TempList
# End of BinStrToList

# The CreateCertBinFile opens a binary and text file and writes the certificate data into it
def CreateCertBinFile(logFile, binStr, txtList, certFileName):
    try:
        # Open a binary file and write the data to it
        FileObj = open(certFileName, "wb")
        FileObj.write(binStr.raw)
        FileObj.close()

        # Assemble the text file name (cert + number 1 for primary , 2 for secondary + .txt)
        certFileNameTxt = certFileName[:-4] + '_' + Cert_FileName + Cert_FileExtTxt
        # Open a text file and write the data into it, in lines of 4 bytes
        FileObj = open(certFileNameTxt, "w")

        NumOfChars = len(txtList)
        if DEBUG_MODE == DEBUG_MODE_OFF:
            FileObj.write("char cert_bin_image[] = {\n")
            for i in range(NumOfChars):
                FileObj.write(txtList[i])
                if i !=  NumOfChars-1:
                    FileObj.write(',')
                if (i+1) % 4 == 0:
                    FileObj.write('\n')
            FileObj.write("}")
        if DEBUG_MODE == DEBUG_MODE_ON:
            wordsList = CreateWordsListFromBytesList(txtList)
            for obj in wordsList:
                FileObj.write(obj + ",")
                FileObj.write('\n')
        FileObj.close()
    except IOError as Error7:
        (errno, strerror) = Error7.args
        print_and_log(logFile, "Error in openning file - %s" %certFileName)
        sys.exit(1)
    return
# End of CreateCertBinFile

def CreateWordsListFromBytesList(BytesList):
    # Create words in reverse order
    wordsList = list()
    if PrjDefines[LIST_OF_CONF_PARAMS.index("CERT_ENDIANITY")] == CERT_IN_LITTLE_ENDIAN:
        length = len(BytesList)/4
        for i in range(int(length)):
            tmpStr = str()
            for j in range(4):
                byte = str()
                byte = BytesList[i*4 + 4 - j - 1]
                byte = byte[2:]
                tmpStr = tmpStr + byte
            tmpStr = '0x' + tmpStr
            wordsList.append(tmpStr)
    else:
        for i in range(len(BytesList)/4):
            tmpStr = str()
            for j in range(4):
                tmpStr = tmpStr + BytesList[i*4 + j]
            wordsList.append(tmpStr)
    return wordsList

# The function writes the hash-digests to output files
def WriteHashDigestsToFile(logFile, digestList, ArgsDict):
    if digestList is None:
        return
    try:
        Cnt = 1
        for digest in digestList:
            outFilePath = ArgsDict[str('hash-out%d' % Cnt)]
            if outFilePath is not None:
                # Open a binary file and write the data to it
                FileObj = open(outFilePath, 'wb')
                FileObj.write(digest)
                FileObj.close()
            Cnt += 1

    except IOError as Error7:
        (errno, strerror) = Error7.args
        print_and_log(logFile, "Error in openning file - %s" % outFilePath)
        sys.exit(1)
    return

########### certificate creation - Utility functions End ###########

# Get item name
def get_item_fname(log_file, config, section_name, src_item_name, dst_item_name, local_dict):
    if config.has_option(section_name, src_item_name):				#  4Key 20160216
        local_dict[dst_item_name] = config.get(section_name, src_item_name)
        log_sync(log_file,src_item_name + ": " + local_dict[dst_item_name] + "\n")
    else:
        local_dict[dst_item_name] = None

# Parse given configuration file and return attributes as dictionary
def parse_config_file (config_fname, log_file):

    try:
        config_file = open(config_fname, 'r')
    except IOError as e:
        print_and_log(log_file,"Failed opening " + config_fname + " (" + e.strerror + ")\n")
        sys.exit(e.errno)

    config = configparser.ConfigParser()
    config.readfp(config_file)
    config_file.close()

    local_dict = dict()
    section_name = "KEY-CFG"
    if not config.has_section(section_name):
        print_and_log(log_file, "section " + section_name + " wasn't found in cfg file\n")
        return None

    if config.has_option(section_name, 'cert-keypair'):
        local_dict['cert_keypair1'] = config.get(section_name, 'cert-keypair')
        log_sync(log_file,"cert-keypair: " + local_dict['cert_keypair1'] + "\n")
    else:
        get_item_fname(log_file, config, section_name, 'cert-keypair1', 'cert_keypair1', local_dict)
    src_item_list = ["cert-keypair2", "cert-keypair3", "cert-keypair4"]
    dst_item_list = ["cert_keypair2", "cert_keypair3", "cert_keypair4"]
    current = 0
    while current < len(src_item_list):
        get_item_fname(log_file, config, section_name, src_item_list[current], dst_item_list[current], local_dict)
        current += 1

    if config.has_option(section_name, 'cert-keypair-pwd'):
        local_dict['cert_keypair_pwd1'] = config.get(section_name, 'cert-keypair-pwd')
        log_sync(log_file,"cert-keypair-pwd: " + local_dict['cert_keypair_pwd1'] + "\n")
    else:
        get_item_fname(log_file, config, section_name, 'cert-keypair-pwd1', 'cert_keypair_pwd1', local_dict)
    src_item_list = ["cert-keypair-pwd2", "cert-keypair-pwd3", "cert-keypair-pwd4"]
    dst_item_list = ["cert_keypair_pwd2", "cert_keypair_pwd3", "cert_keypair_pwd4"]
    current = 0
    while current < len(src_item_list):
        get_item_fname(log_file, config, section_name, src_item_list[current], dst_item_list[current], local_dict)
        current += 1

    local_dict['hbk_id'] = int(config.get(section_name, 'hbk-id'))
    if (local_dict['hbk_id'] != int(0) and local_dict['hbk_id'] != int(1) and local_dict['hbk_id'] != int(2)) :
        log_sync(log_file, "Illegal hbk-id defined - exiting\n")
        return None
    log_sync(log_file,"hbk-id: " + str(local_dict['hbk_id']) + "\n")

    local_dict['nvcounter_id'] = int(config.get(section_name, 'nvcounter-id'))
    if (local_dict['nvcounter_id'] != int(1) and local_dict['nvcounter_id'] != int(2)):
        log_sync(log_file, "Ilegal nvcounter-id defined - exiting\n")
        return None
    log_sync(log_file,"nvcounter-id: " + str(local_dict['nvcounter_id']) + "\n")

    local_dict['nvcounter_val'] = int(config.get(section_name, 'nvcounter-val'))
    if (local_dict['nvcounter_id'] == int(1) and local_dict['nvcounter_val'] >= int(32)):
        log_sync(log_file, "Ilegal nvcounter-val for trsuted NV-Counter defined - exiting\n")
        return None
    if (local_dict['nvcounter_id'] == int(2) and local_dict['nvcounter_val'] >= int(224)):
        log_sync(log_file, "Ilegal nvcounter-val for non-trsuted NV-Counter defined - exiting\n")
        return None
    log_sync(log_file,"nvcounter-val: " + str(local_dict['nvcounter_val']) + "\n")

    local_dict['next_cert_pubkey'] = config.get(section_name, 'next-cert-pubkey')
    log_sync(log_file,"next-cert-pubkey: " + local_dict['next_cert_pubkey'] + "\n")

    local_dict['cert-pkg'] = config.get(section_name, 'cert-pkg')
    log_sync(log_file,"cert-pkg: " + local_dict['cert-pkg'] + "\n")


    if config.has_option(section_name, 'hash-out'):
        local_dict['hash-out1'] = config.get(section_name, 'hash-out')
        log_sync(log_file,"hash-out: " + local_dict['hash-out1'] + "\n")
    else:
        get_item_fname(log_file, config, section_name, 'hash-out1', 'hash-out1', local_dict)
    src_item_list = ["hash-out2", "hash-out3", "hash-out4"]
    dst_item_list = ["hash-out2", "hash-out3", "hash-out4"]
    current = 0
    while current < len(src_item_list):
        get_item_fname(log_file, config, section_name, src_item_list[current], dst_item_list[current], local_dict)
        current += 1


    return local_dict

# Parse script parameters
def parse_shell_arguments ():
    len_arg =  len(sys.argv)
    if len_arg < 2:
        print("len " + str(len_arg) + " invalid. Usage:" + sys.argv[0] + "<test configuration file>\n")
        for i in range(1,len_arg):
            print("i " + str(i) + " arg " + sys.argv[i] + "\n")
        sys.exit(1)
    config_fname = sys.argv[1]
    if len_arg == 3:
        log_fname = sys.argv[2]
    else:
        log_fname = "sb_key_cert.log"
    return config_fname, log_fname


#################################################################################
# The function analyzes the input files and creates a key certificate binary file to be used in the
# secure boot process.
#
def CreateCertUtility(sysArgsList):
    try:
        result = True
        resultMsg = ''

        config_fname, log_fname =  parse_shell_arguments()

        log_file = create_log_file(log_fname)
        # Check the input parameters and save it to list
        ArgsDict = parse_config_file(config_fname, log_file)
        if ArgsDict == None:
               log_file.close()
               exit(1)


        print_and_log(log_file, "**** Creating Key certificate Table **** ")

        # create KeyCertificate
        result, resultMsg, CertPkg, DigestList = CreateKeyCert(ArgsDict)
        if result == True:
            # output
            print_and_log(log_file, "\n Write the certificate to file ")
            # Write binary and text string to file
            CreateCertBinFile(log_file, CertPkg, BinStrToList(CertPkg), ArgsDict['cert-pkg'])
            # Write hash-digests
            WriteHashDigestsToFile(log_file, DigestList, ArgsDict)

            print_and_log(log_file, "\n**** Certificate file creation has been completed successfully ****")
        else:
            print_and_log(log_file, "\n**** Certificate file creation failed ****")

    except IOError as Error8:
        (errno, strerror) = Error8.args
        print_and_log(log_file, "I/O error(%s): %s" % (errno, strerror))
        raise
    except NameError:
        print_and_log(log_file, "Unexpected error, exiting program")
        raise  # Debug info
    except ValueError:
        print_and_log(log_file, "Illegal variable type")
        raise # Debug info


##################################
#       Main function
##################################

if __name__ == "__main__":

    import sys
    if sys.version_info<(3,0,0):
        print("You need python 3.0 or later to run this script")
        exit(1)

    if "-cfg_file" in sys.argv:
        PROJ_CONFIG = sys.argv[sys.argv.index("-cfg_file") + 1]
    print("Config File  - %s\n" %PROJ_CONFIG)

    # Get the project configuration values
    PrjDefines = parseConfFile(PROJ_CONFIG,LIST_OF_CONF_PARAMS)

    CreateCertUtility(sys.argv)








######################################## END OF FILE ########################################

