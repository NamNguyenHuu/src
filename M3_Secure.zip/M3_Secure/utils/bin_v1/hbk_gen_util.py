#!/usr/local/bin/python3
###############################################################################
# Copyright (c) 2015-2018, Renesas Electronics Corporation                    #
# All rights reserved.                                                        #
###############################################################################


import sys
import os
from datetime import datetime
import struct
import ctypes

# Definitions for paths
#######################
if sys.platform != "win32" :
    path_div = "//"
else : #platform = win32
    path_div = "\\"

CURRENT_PATH = sys.path[0]
# In case the scripts were run from current directory
CURRENT_PATH_SCRIPTS = path_div + 'sbu_scripts'

# this is the scripts local path, from where the program was called
sys.path.append(CURRENT_PATH+CURRENT_PATH_SCRIPTS)

import string
from ctypes import *
from cert_basic_utilities import *
#from global_defines import *


# Prim key hash file name
PRIM_KEY_HASH_FILE_NAME = "prim_key_hash.txt"
ZEROS_NUM_FILES_NAME = "zero_bits_in_hash.txt"

####################################################################
# Filename - hbk_gen_util.py
# Description - This file is responsible for creation of public key
#               HASH and its corresponding number of Zeroes
#               as it should be saved in the OTP/NVM
####################################################################

#################### Utility functions #############################

# The function writes the output to output files
def WriteOutputToFile(buffData, outFilePath):

    try:
        buff_p = ctypes.cast(buffData, ctypes.c_char_p)
        # Open a binary file and write the data to it
        FileObj = open(outFilePath, 'w')
        FileObj.write("%s" % buff_p.value.decode('utf-8'))
        FileObj.close()

    except IOError as Error7:
        (errno, strerror) = Error7.args
        print_and_log(logFile, "Error in openning file - %s" %certFileName)
        sys.exit(1)
    return


# This function prints the instructions of how to operate the utility
def usage():
    print("""Syntax: ./hbk_gen_util.py -cert <Key certificate file name> -endian <optional endianness> -hash_format <optional hash_format> \n
hbk_gen_util.py creates HASH over concatenation of N (public key) and Np (Barrett N' value) and calculates number of zero bits over the HASH value.\n
Input arguments:\n
-key <Key file name> or -cert <Key certificate file name>\n
-endian <endianness, B||L> - optional, endianness flag, B for Big endian or L for little endian; default is little endian\n
-hash_format <[SHA256 | SHA256_TRUNC]> - optional, HASH algorithm identifier determines the hash public key size; default is SHA256\n
outputs:\n
"prim_key_hash.txt" - file containing primary key hash text file in word format\n
"zero_bits_in_hash.txt" - file containing number of zeros for primary key hash\n
""")
    sys.exit(1)


# The function parses the input parameters and returns a list of the given parameters
def parse_shell_arguments():
    # Input parameters are :
    # -key [Key file name] or -cert [Key certificate file name]
    # -endian <endianness, B||L> - optional, endianness flag, B for Big endian or L for little endian
    # -hash_format <[SHA256 | SHA256_TRUNC]> - optional, HASH algorithm identifier determines the hash public key size

    sysArgsList = sys.argv

    key_fname = None
    cert_fname = None
    is_key = 0;
    is_cert = 0;

    # check -key option
    if "-key" in sysArgsList:
        key_fname = sysArgsList[sysArgsList.index("-key") + 1]
        is_key = 1

    # check -cert option
    if "-cert" in sysArgsList:
        cert_fname = sysArgsList[sysArgsList.index("-cert") + 1]
        is_cert = 1

    if is_key == 1  and is_cert == 1:
        print("Both -key [Key file name] and -cert [Key certificate file name] are defined - exiting\n")
        usage()
        sys.exit(1)
    if is_key == 0 and is_cert == 0:
        print("-key [Key file name] nor -cert [Key certificate file name] not defined - exiting\n")
        usage()
        sys.exit(1)

    # Read the endianity and set it in the project defines list
    if "-endian" in sysArgsList:
        endianity = sysArgsList[sysArgsList.index("-endian") + 1]
        if (endianity != 'B' and endianity != 'L'):
            print("-endian <[B | L]> is illegal")
            usage()
            sys.exit(1)
    else:
        endianity = "L"

    # check if the hash_format exist; if not, set default to SHA256
    if "-hash_format" in sysArgsList:
        hbk_format = sysArgsList[sysArgsList.index("-hash_format") + 1]
        if (hbk_format != 'SHA256' and hbk_format != 'SHA256_TRUNC'):
            print("-hash_format <[SHA256 | SHA256_TRUNC]> is illegal")
            usage()
            sys.exit(1)
    else:
        hbk_format = "SHA256"

    return key_fname, cert_fname, endianity, hbk_format

##########################################################################################################

# Main functin, responsible for creating HASH value over N | Np and and the corresponding number of Zeroes value.
# The function expects the following inputs :
# 1. RSA public key file name mandatory (key file expected to be in openSSL PEM format)
# 2. Output format flag (L||B) little or big endian (optional, if not given L - little endian will be used)
# 3. hash_format (SHA256||SHA256_TRUNC) (optional, if not given HASH SHA256 size will be used)
# The output will be written to two files: PrimKeyHASH.txt & ZeroBitsInHASH.txt
def main():

    pubKeyFileName, keyCertFileName, endianness, hash_format = parse_shell_arguments()
    log_file = create_log_file("gen_hbk_log.log")
    print_and_log(log_file, str(datetime.now()) + ": generate HBK Utility started (Logging to gen_hbk_log.log)\n")

    result, resultMsg, KeyHash, ZeoBitHsh = CreateHbkHash(pubKeyFileName, keyCertFileName)
    if result == True:
        # output KeyHash
        print_and_log(log_file, "\n Write the KeyHash to file ")
        # Write to file
        WriteOutputToFile(KeyHash, PRIM_KEY_HASH_FILE_NAME)

        # output ZeroBitHash
        print_and_log(log_file, "\n Write the ZeroBitHash to file ")
        # Write to file
        WriteOutputToFile(ZeoBitHsh, ZEROS_NUM_FILES_NAME)

        print_and_log(log_file, "\n**** Function completed successfully. ****")

    else:
        print_and_log(log_file, "\n**** Function failed. ****")

    sys.exit(0)


#############################
if __name__ == "__main__":
    main()




