About the ImageCreate
=====================
<Div Align="right">
Renesas Electronics Corporation<BR>
Apr-26-2017
</Div><BR>

The ImageCreate is sample software.
<br>
It to be combined the several binary images, and convert the combined image to the s-record image.
<br>
For details, refer to the [Application Note](docs/application-note.md).
