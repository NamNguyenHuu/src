#!/bin/sh

echo build_bin_create.sh - ImageCreate V1.0.5 Aug.31,2017

cd bin
gcc -o bin_create bin_create.c
