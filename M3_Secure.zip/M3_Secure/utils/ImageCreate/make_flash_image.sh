#!/bin/sh

echo make_flash_image.sh - ImageCreate V1.0.5 Aug.31,2017

export MAKE_IMAGE_PATH=$PWD

#export SETTING_BOOTPARAM_PATH=setting/bootparam/v1
export SETTING_BOOTPARAM_PATH=setting/bootparam/v2
#export SETTING_CERT_HEADER_PATH=setting/cert_header/flash/v1
export SETTING_CERT_HEADER_PATH=setting/cert_header/flash/v2
#export SETTING_CERT_HEADER_PATH=setting/cert_header/emmc/v1
export SETTING_FLASH_WRITER_PATH=setting/flashwriter
rm ./output/* -fr
rm ./temp/* -fr

cd $MAKE_IMAGE_PATH/temp

$MAKE_IMAGE_PATH/bin/bin_create $MAKE_IMAGE_PATH/$SETTING_BOOTPARAM_PATH/bootparam_image_SA0.txt $MAKE_IMAGE_PATH/temp/bootparam_sa0.bin
$MAKE_IMAGE_PATH/bin/bin_create $MAKE_IMAGE_PATH/$SETTING_CERT_HEADER_PATH/cert_header_image_SA6.txt $MAKE_IMAGE_PATH/temp/cert_header_sa6.bin
$MAKE_IMAGE_PATH/bin/bin_create $MAKE_IMAGE_PATH/$SETTING_FLASH_WRITER_PATH/flashwriter.txt $MAKE_IMAGE_PATH/temp/AArch64_Flash_writer_SCIF_E6304000_salvator-x.bin
objcopy -I binary -O srec --adjust-vma=0xE6320000 --srec-forceS3 $MAKE_IMAGE_PATH/temp/bootparam_sa0.bin $MAKE_IMAGE_PATH/output/bootparam_sa0.srec
objcopy -I binary -O srec --adjust-vma=0xE6320000 --srec-forceS3 $MAKE_IMAGE_PATH/temp/cert_header_sa6.bin $MAKE_IMAGE_PATH/output/cert_header_sa6.srec
objcopy -I binary -O srec --adjust-vma=0xE6300400 --srec-forceS3 $MAKE_IMAGE_PATH/temp/AArch64_Flash_writer_SCIF_E6304000_salvator-x.bin $MAKE_IMAGE_PATH/output/AArch64_Flash_writer_SCIF_E6304000_salvator-x.mot
