import struct

# Định nghĩa các giá trị của AesIVData
aes_iv_data = [0xAB, 0x02, 0xCD, 0xEF, 0x33, 0x54, 0xFF, 0x01, 0x88, 0x88, 0x88, 0x88, 0x88, 0x88, 0x88, 0x88]

# Chuyển đổi danh sách AesIVData thành chuỗi byte
aes_iv_data_bytes = struct.pack('B'*len(aes_iv_data), *aes_iv_data)

# Ghi chuỗi byte vào tệp nhị phân
with open('AesIVData.bin', 'wb') as bin_file:
    bin_file.write(aes_iv_data_bytes)

# Kiểm tra nội dung tệp sau khi ghi
with open('AesIVData.bin', 'rb') as bin_file:
    data = bin_file.read()
    print("Nội dung của AesIVData.bin:")
    print(' '.join(f'0x{byte:02X}' for byte in data))