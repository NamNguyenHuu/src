def convert_txt_to_bin(txt_filename, bin_filename):
    with open(txt_filename, 'r') as txt_file:
        hex_data = txt_file.read().strip()
    
    # Remove '0x' and split by commas
    hex_values = hex_data.replace('0x', '').split(',')
    
    # Convert hex values to bytes
    byte_data = bytes([int(h, 16) for h in hex_values])
    
    # Write bytes to the binary file
    with open(bin_filename, 'wb') as bin_file:
        bin_file.write(byte_data)

# Example usage
txt_filename = 'kce.txt'
bin_filename = 'kce.bin'
convert_txt_to_bin(txt_filename, bin_filename)