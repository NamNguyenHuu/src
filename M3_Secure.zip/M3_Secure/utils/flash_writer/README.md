About the Flash writer
=====================
<Div Align="right">
Renesas Electronics Corporation<BR>
Jun-4-2021
</Div><BR>

The eMMC writer renamed to Flash writer.  
The Flash writer is sample software for R-Car H3 / M3 / M3N / E3 / D3 series.  
The Flash writer downloads the some of the raw images from Host PC via SCIF or USB, and writes the raw images to the Serial NOR Flash and HyperFlash&trade;, eMMC.

For details on how to use this sample software, refer to the [application note](docs/application-note.md).
