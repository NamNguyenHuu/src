#!/bin/bash
#set -x

BASEDIR="/shsv/Android/SoftIP/sec_bsp/M3_Secure"
LSI="salvator-x"
Boot_mode=$1			##0 with M3 ##1 with M3N
LSI_VARIANT="$2"		##M3 ##M3N
TA_ENC=$3 #### ta_encryption ######### 0 = NO, default ########### 1 = YES ##########

BurnIPL=${BASEDIR}/image_secure/$LSI_VARIANT # contains raw ipls
case $Boot_mode in
	0)	SecureIPL=${BurnIPL};;
	1)	SecureIPL=${BurnIPL};;
esac

PC_tools=${BASEDIR}/utils
IC_DIR=${PC_tools}/ImageCreate
##========================== IMPLEMENTATION ==========================

# Function to create certificates
function create_certificates_bin() {
    cd "$PC_tools" || exit
    python3 bin/cert_key_util.py 		sbu_input/cfg_file/sb_key_cert.cfg
	python3 bin/cert_sb_content_util.py sbu_input/cfg_file/sb_bl2_cert.cfg
    python3 bin/cert_sb_content_util.py sbu_input/cfg_file/sb_bl31_cert.cfg
    python3 bin/cert_sb_content_util.py sbu_input/cfg_file/sb_bl32_cert.cfg
    python3 bin/cert_sb_content_util.py sbu_input/cfg_file/sb_bl33_cert.cfg
	python3 bin/cert_sb_content_util.py sbu_input/cfg_file/sb_flashwriter_cert.cfg
    cp -r sbu_output/sb_key_cert.bin "$IC_DIR/input/"
    cp -r sbu_output/images/*_cert.bin "$IC_DIR/input/"
	# cp -r sbu_input/flash_writer/AArch64_Flash_writer_SCIF_E6304000_salvator-x_enc.bin "$IC_DIR/input/"
	cp -r sbu_input/flash_writer/AArch64_Flash_writer_SCIF_E6304000_salvator-x.bin "$IC_DIR/input/"
	cp -p sbu_output/flash_writer/flashwriter_cert.bin $IC_DIR/input/
}

## This function creates: bootparam_sa0.srec, cert_header_sa6.srec.
function create_bootparam_header_cert_srec() {
	# Build the "bin_create".
	cd $IC_DIR
	./build_bin_create.sh  
	./make_flash_image.sh
	cp -r output/*.srec $SecureIPL
	case $Boot_mode in
	0)	cp -r output/AArch64_Flash_writer_SCIF_E6304000_salvator-x.mot $SecureIPL/AArch64_Gen3_H3_M3_Scif_MiniMon_V5.11.mot;;
	1)	cp -r output/AArch64_Flash_writer_SCIF_E6304000_salvator-x.mot $SecureIPL/AArch64_Gen3_Scif_MiniMon_Develop_M3N_V0.03.mot;;
	esac
	
	cd -
}


function create_srec_files() {
    objcopy -I binary -O srec --adjust-vma=0xE6304000 --srec-forceS3 "$PC_tools/sbu_input/images/bl2-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/bl2-${LSI}.srec"
    objcopy -I binary -O srec --adjust-vma=0x44000000 --srec-forceS3 "$PC_tools/sbu_input/images/bl31-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/bl31-${LSI}.srec"
    objcopy -I binary -O srec --adjust-vma=0x44100000 --srec-forceS3 "$PC_tools/sbu_input/images/tee-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/tee-${LSI}.srec"
    objcopy -I binary -O srec --adjust-vma=0x50000000 --srec-forceS3 "$PC_tools/sbu_input/images/u-boot-elf-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/u-boot-elf-${LSI}.srec"
	# objcopy -I binary -O srec --adjust-vma=0xffffffff --srec-forceS3 "$PC_tools/sbu_input/images/bl2-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/bl2-${LSI}.srec"
    # objcopy -I binary -O srec --adjust-vma=0xffffffff --srec-forceS3 "$PC_tools/sbu_input/images/bl31-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/bl31-${LSI}.srec"
    # objcopy -I binary -O srec --adjust-vma=0xffffffff --srec-forceS3 "$PC_tools/sbu_input/images/tee-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/tee-${LSI}.srec"
    # objcopy -I binary -O srec --adjust-vma=0xffffffff --srec-forceS3 "$PC_tools/sbu_input/images/u-boot-elf-${LSI}${enc_extension}.bin" "$PC_tools/sbu_output/images/u-boot-elf-${LSI}.srec"
    cp -rf "$PC_tools/sbu_output/images/"*-${LSI}.srec "$SecureIPL"
    ls -l "$SecureIPL"/*.srec
}

# Function to perform padding
function perform_padding() {
    local image_file="$1"
    local padding_address="$2"
    local certificate_file="$3"

    local image_path="${PC_tools}/sbu_input/images/${image_file}"
	# ls -l ${PC_tools}/sbu_input/images/*
    local null_padding=$((16 - $(stat -c %s "$image_path") % 16))
	
    echo "Adding ${null_padding} null padding bytes to $image_file"
    dd if=/dev/zero bs=1 count="$null_padding" >> "$image_path"

}

# Function to perform padding for images
function ipl_padding() {
	declare -A image_info=(		
			["bl2-${LSI}.bin"]="0x00000000E6304000"
			["bl31-${LSI}.bin"]="0x0000000044000000"
			["tee-${LSI}.bin"]="0x0000000044100000"
			["u-boot-elf-${LSI}.bin"]="0x0000000050000000"
		)
		
    for image_file in "${!image_info[@]}"; do
        perform_padding "$image_file" "${image_info[$image_file]}" "${image_file%.*}_cert.bin"
    done

}
## =========================== EXECUTION =============================
  		
export key=$PC_tools/sbu_output/sb_key_cert.bin	
export cnt=$PC_tools/sbu_output/ta/sb_ta_cert.bin
#export raw_ta=$PC_tools/sbu_input/ta/no_cert.ta
#export enc_ta=$PC_tools/sbu_input/ta/no_cert_enc.bin
#export cert_ta=$PC_tools/sbu_output/ta/9abd4fe0-7ed5-11e5-baf5-0002a5d5c51b.ta

case "$TA_ENC" in ##NO_ENC_TA=0, ENC_TA=1
	0)
	echo "IMAGES ENCRYTION = NO"
	enc_extension=""
#	ls -l $PC_tools/sbu_input/ta/no_cert.ta
	ipl_padding
	create_certificates_bin
	create_srec_files
	create_bootparam_header_cert_srec
#	cat $key $cnt $raw_ta > $cert_ta 
#	chmod 777 $cert_ta
#	cp -p ${cert_ta}			/tftpboot/truongnguyen/rootfs_M3/lib/optee_armtz
	;;
	
	1)
	echo "IMAGES ENCRYTION = YES"
	enc_extension="_enc"
	create_certificates_bin
	create_srec_files
	create_bootparam_header_cert_srec
#	cat $key $cnt $enc_ta > $cert_ta
#	chmod 777 $cert_ta
#	cp -p ${cert_ta}			/tftpboot/truongnguyen/rootfs_M3/lib/optee_armtz
	# ;;
esac
