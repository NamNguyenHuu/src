#!/usr/bin/env python3
"""
####################################################################################################
# Copyright [2020 - 2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
#
# The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics
# Corporation and/or its licensors ("Renesas") and subject to statutory and contractual protections.
#
# Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy,
# modify, distribute, display, or perform the contents; 2) you may not use any name or mark of
# Renesas for advertising or publicity purposes or in connection with your use of the contents;
# 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY
# PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING
# THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT;
# AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
# INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT
# OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS.
# Third-party contents included in this file may be subject to different terms.
#
# Description: This file is the Python script to read the console output from actual board.
####################################################################################################
****************************************************************************************************
* File Name    : ipl_burning.py
* Version      : 8.0.0
* Product Name : CI/CD
* Device(s)    : N/A
* Description  : Scripts to run on host pc to execute the target board.
*
****************************************************************************************************
****************************************************************************************************
* History   Version   DD.MM.YYYY   Description
* 92a6b55   1.0.0     18.05.2018   Initial version.
* 5a5530a   2.0.0     29.10.2018   Add support for H3, M3, M3N, E3.
* 9be047d   3.0.0     22.06.2020   Add support for V3H.
* 4e1114c   4.0.0     16.07.2020   Add support for M3ULCB, H3ULCB.
* 75e274a   5.0.0     18.09.2020   Add support for V3U.
* 1d81e25   6.0.0     26.10.2020   Add encode/decode string data to bytes type.
* 4cb17f0   7.0.0     26.04.2021   Separate FILE_IPL and FILE_MOT to another json file.
* 0e7b49f   7.1.0     03.05.2021   Add more baudrate options.
* 220cf35   7.2.0     04.05.2021   Parse image address in srec files.
* 88422d8   8.0.0     07.10.2021   Add support for S4.
****************************************************************************************************
"""
####################################################################################################
# Import from standard libraries
####################################################################################################
import serial
import sys
import time
import os
import json
import bincopy
from serial.tools.list_ports import comports


####################################################################################################
# Print debug data
####################################################################################################
def print_debug(type_mesg, data):
    if sys.platform == "win32":
        if type_mesg == "ERROR":
            PREFIX = "[ERROR]"
        elif type_mesg == "WARNING":
            PREFIX = "[WARNING]"
        elif type_mesg == "INFO":
            PREFIX = "[INFO]"
    else:
        if type_mesg == "ERROR":
            PREFIX = "[\033[01;31mERROR\033[01;0m]"
        elif type_mesg == "WARNING":
            PREFIX = "[\033[01;33mWARNING\033[01;0m]"
        elif type_mesg == "INFO":
            PREFIX = "[\033[01;34mINFO\033[01;0m]"
    print("%s %s" % (PREFIX, data))


class Serial_conn(serial.Serial):
    """
    Serial connection class
    """
    # send a command line
    def sendln(self, cmd_to_send=""):
        str_send = cmd_to_send + "\r"
        return self.write(str_send.encode())

    # send a string
    def send(self, cmd_to_send=""):
        str_send = cmd_to_send
        return self.write(str_send.encode())

    # send a file
    def sendfile(self, file_path):
        print_debug("INFO", "Sending file %s" % file_path)
        return self.write(open(file_path, "rb").read())

    # wait a line by pattern, then send next_command if any, timeout 10 in minutes
    def wait(self, pattern, delay_send=0, cmd_to_send="NONE", time_out=600):
        buffer = ""
        end_time = int(time.time()) + time_out
        while int(time.time()) < end_time:
            bytes_to_read = self.inWaiting()
            if bytes_to_read:
                line = self.read(bytes_to_read).decode('ISO-8859-1')
                buffer += line
                sys.stdout.write(line)
                sys.stdout.flush()
                if pattern in buffer:
                    time.sleep(delay_send)
                    if cmd_to_send != "NONE":
                        self.sendln(cmd_to_send)
                    return 0
        return 255

    # wait for a pattern in list, then send command if any, timeout 10 in minutes
    def waitls(self, patternList=[], delay_send=0, cmd_to_send="NONE", time_out=600):
        buffer = ""
        end_time = int(time.time()) + time_out
        while int(time.time()) < end_time:
            bytes_to_read = self.inWaiting()
            if bytes_to_read:
                line = self.read(bytes_to_read).decode('ISO-8859-1')
                buffer += line
                sys.stdout.write(line)
                sys.stdout.flush()
                index = 0
                for pattern in patternList:
                    if pattern in buffer:
                        time.sleep(delay_send)
                        if cmd_to_send != "NONE":
                            self.sendln(cmd_to_send)
                        return index
                    index = index + 1
        return 255  # timeout


####################################################################################################
# Burn file
####################################################################################################
def get_imgaddr(file):
    """Get Image address in file srec. """
    f = bincopy.BinFile()
    f.add_srec_file(file)
    return format(f.minimum_address, "08X")


def burn_file(dev, option, ipl_path, soc, ipl_config):
    file_name = os.path.join(ipl_path, ipl_config[option]["name"])
    img_addr = get_imgaddr(file_name)
    flash_addr = ipl_config[option]["flash_addr"]

    dev.sendln()
    dev.wait(">", 0.2, "xls2")
    if any(board in soc for board in ["v3u", "s4", "v4h"]):
        dev.wait("Select (1-3)>", 0.1, "1")
    else:
        dev.wait("Select (1-3)>", 0.1, "3")

    res = 0
    while res == 0:
        ex_list = ["Setting OK? (Push Y key)", "H'"]
        res = dev.waitls(ex_list, 0.1)
        if res == 0:
            dev.send("y")
            time.sleep(0.1)

    dev.sendln(img_addr)
    dev.wait("Please Input : H", 0.2, flash_addr)
    dev.wait("CR stop load)", 0.2)
    dev.sendfile(file_name)

    ex_list = ["Clear OK?(y/n)", ">"]
    res = dev.waitls(ex_list, 0.1)
    if res == 0:
        dev.send("y")
        time.sleep(0.2)
        dev.sendln()
        dev.sendln()


####################################################################################################
# Help
####################################################################################################
def help(ipl_config):
    print("\tPlease use as syntax below:")
    print("\t python ipl_burning.py [SOC] [SERIAL] [PATH_TO_FILE_MOT] [PATH_TO_IPL_FILE] [OPTION]")
    print("\t    [SOC]          : %s" % ipl_config["flash_writer"].keys())
    print("\t    [SERIAL]       : %s " % [node.device for node in list(comports())])
    print("\t    [PATH_TO_FILE_MOT]")
    print("\t    [PATH_TO_IPL_FILE]")
    print("\t    [OPTION]:")
    print("\t       all               : download all of file ipl")
    print("\t       <name_of_file>    : download only file ipl <name_of_file>")
    print("\t       param  : download file bootparam...")
    print("\t       bl2    : download file bl2...")
    print("\t       cr7    : download file cr7...")
    print("\t       cert3  : download file cert_header_sa3...")
    print("\t       cert6  : download file cert_header_sa6...")
    print("\t       cert17 : download file cert_header_sa17...")
    print("\t       tee    : download file tee...")
    print("\t       fw     : download file dummy_fw...")
    print("\t       rtos   : download file dummy_rtos...")
    print("\t       icumxa : download file icumxa_loader...")
    print("\t       icumh  : download file dummy_icumh...")
    print("\t       g4mh   : download file dummy_g4mh...")
    print("\t       bl31   : download file bl31...")
    print("\t       smoni  : download file smoni...")
    print("\t       uboot  : download file u-boot...")
    exit(1)


####################################################################################################
# Main
####################################################################################################
def main():
    with open("ipl_burning.json") as ipl_config_file:
        ipl_config = json.load(ipl_config_file)

    if len(sys.argv) < 6:
        print_debug("ERROR", "Lack of argument")
        help(ipl_config)

    if str(sys.argv[1]) not in ipl_config["flash_writer"].keys():
        print_debug("ERROR", 'in valid soc name "%s"' % str(sys.argv[1]))
        help(ipl_config)
    SOC = str(sys.argv[1])

    DEV_NODE = None
    nodes = list(comports())
    if sys.platform == "win32":
        serial_path = str(sys.argv[2])
    else:
        serial_path = os.path.realpath(str(sys.argv[2]))
    for node in nodes:
        if serial_path == node.device:
            DEV_NODE = str(sys.argv[2])
            break

    if DEV_NODE is None:
        print_debug("ERROR", "%s is not exists" % str(sys.argv[2]))
        help(ipl_config)

    if os.path.exists(str(sys.argv[3] + "/" + ipl_config["flash_writer"][SOC])):
        MOT_DIR = str(sys.argv[3])
    else:
        print_debug("ERROR", "%s/%s is not exists" % (sys.argv[3], ipl_config["flash_writer"][SOC]))
        exit(1)

    if os.path.exists(str(sys.argv[4])):
        IPL_DIR = str(sys.argv[4])
    else:
        print_debug("ERROR", "%s is not exists" % str(sys.argv[4]))
        help(ipl_config)

    # get IPL shortened option
    option = sys.argv[5:]
    ALL_OPTION = [opt for opt in ipl_config["ipl"][SOC]]
    if "all" in option:
        option = ALL_OPTION
    elif not set(option).issubset(ALL_OPTION):
        print_debug("ERROR", "Wrong ipl option!")
        print_debug("ERROR", "Use these options for %s: %s" % (SOC, ALL_OPTION))
        exit(1)

    # check srec files
    ret = 0
    FILE_IPL_WILL_BURN = []
    IMGADR_WILL_BURN = []
    FLASHADR_WILL_BURN = []
    for opt in option:
        if not os.path.exists(IPL_DIR + "/" + ipl_config["ipl"][SOC][opt]["name"]):
            ret = 1
            print_debug("ERROR", "%s is not exists" % ipl_config["ipl"][SOC][opt]["name"])
            continue
        FILE_IPL_WILL_BURN.append(ipl_config["ipl"][SOC][opt]["name"])
        IMGADR_WILL_BURN.append(get_imgaddr(IPL_DIR + "/" + ipl_config["ipl"][SOC][opt]["name"]))
        FLASHADR_WILL_BURN.append(ipl_config["ipl"][SOC][opt]["flash_addr"])

    if ret == 1:
        exit(1)
    print_debug("INFO", "Download IPL for %s with serial device %s" % (SOC, DEV_NODE))
    print_debug("INFO", "File .mot at %s:" % MOT_DIR)
    print_debug("INFO", "    %s" % ipl_config["flash_writer"][SOC])
    print_debug("INFO", "File .srec at %s:" % IPL_DIR)
    print_debug("INFO", "    %s" % FILE_IPL_WILL_BURN)
    print_debug("INFO", "Image address: \n\t\t%s" % IMGADR_WILL_BURN)
    print_debug("INFO", "flash address: \n\t\t%s" % FLASHADR_WILL_BURN)

    # Serial config
    if "s4" in SOC:
        BAUDRATE = 1843200
    elif "v4h" in SOC:
        BAUDRATE = 921600
    else:
        BAUDRATE = 115200
    test_dev = Serial_conn(
        port=DEV_NODE,
        baudrate=BAUDRATE,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
    )

    if not test_dev.isOpen():
        test_dev.open()
    print_debug("INFO", "Monitor file sending...")
    sys.stdout.flush()
    test_dev.sendfile(MOT_DIR + "/" + ipl_config["flash_writer"][SOC])
    print_debug("INFO", "Send file .mot done")
    sys.stdout.flush()
    test_dev.wait(">", 0.2, "\r")

    if not any(board in SOC for board in ["s4", "v4h"]):
        test_dev.wait(">", 0.2, "sup")
        ex_list = [
            "Please change to 921.6Kbps baud rate setting of the terminal.",
            "Please change to 460.8Kbps baud rate setting of the terminal.",
            "Change to 460.8Kbps baud rate setting of the SCIF. OK? (y/n)"
        ]
        res = test_dev.waitls(ex_list, 0.2)
        if res == 0:
            BAUDRATE = 921600
        elif res == 1:
            BAUDRATE = 460800
        else:
            test_dev.send("y")
            time.sleep(0.2)
            test_dev.sendln()
            BAUDRATE = 460800

        test_dev.baudrate = BAUDRATE

    # Loading srec
    test_dev.send("\n")

    for opt in option:
        burn_file(test_dev, opt, IPL_DIR, SOC, ipl_config["ipl"][SOC])

    test_dev.wait(">", 1)
    print_debug("INFO", "Download file .srec done")
    test_dev.baudrate = 115200
    test_dev.close()
    exit(0)


if __name__ == "__main__":
    main()
